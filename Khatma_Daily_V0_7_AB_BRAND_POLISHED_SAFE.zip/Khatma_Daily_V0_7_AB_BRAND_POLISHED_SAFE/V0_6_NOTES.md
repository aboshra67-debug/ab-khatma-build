# AB Khatma V0.6 — Themes Applied Safe

- Safe patch based on V0.5; no working feature removed.
- Noor theme: ivory / deep green / gold.
- Emerald theme: deep emerald dark palette with gold accents.
- Night theme: navy dark palette with purple and gold accents.
- Theme choice is still persisted locally with ThemePreferences.
- Home screen redesigned to visibly reflect the selected theme: hero progress card, themed group cards, CTAs and quick actions.
- Appearance screen now includes visual palette previews and an immediate selected-state border.
- Global shapes and typography refined for a calmer Quran-reading UI.
- Network, PostgreSQL, offline synchronization, group logic, prayer notifications and Quran reader behavior were not deleted or replaced.
- Launcher/logo files were intentionally left for the next separate logo step.
