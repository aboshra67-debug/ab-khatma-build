# AB Khatma V0.5 — Brand + Theme + Install Fix

- applicationId changed to `com.ab.khatma.app` to avoid residual/conflicting test-package installs.
- versionCode 5 / versionName 0.5.0.
- Added real adaptive launcher icon (Quran book + crescent/star identity).
- Added 3 persistent themes: Noor, Emerald, Night.
- Added Appearance screen and palette shortcut from Home.
- Keeps the V0.4 network/offline/prayer/Quran structure unchanged.
- Recommended build: assembleDebug for device testing, plus `apksigner verify` before artifact upload.
