# Quran Data Integrity Policy

The application must never generate, reconstruct, autocorrect, normalize, or manually retype Quran text for release.

Planned text source: **Tanzil Project — Uthmani Quran Text, Version 1.1**.

Required integration rules:
1. Import the Quran text verbatim from the verified source.
2. Do not change the Quran text.
3. Clearly indicate Tanzil Project as the source in the application.
4. Provide a link to `tanzil.net` so users can track text updates.
5. Include the Tanzil copyright/license notice with any distributed copy or derived data file containing a substantial portion of the text.
6. Validate the generated Android asset before release: 114 surahs, 6236 ayahs, valid Juz 1..30, and valid Medina Mushaf page metadata.
7. Keep generated metadata separate from the immutable verse text where practical.

The V0.3 package contains only the reader/repository structure; it deliberately does not ship an unverified Quran text file.
