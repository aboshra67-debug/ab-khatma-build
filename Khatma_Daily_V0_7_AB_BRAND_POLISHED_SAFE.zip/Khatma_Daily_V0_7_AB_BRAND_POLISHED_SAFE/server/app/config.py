from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    database_url: str = "postgresql+psycopg://khatma:khatma@localhost:5432/khatma_db"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
