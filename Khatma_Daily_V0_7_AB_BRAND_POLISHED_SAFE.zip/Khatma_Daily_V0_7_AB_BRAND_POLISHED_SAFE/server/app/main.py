from datetime import date, datetime
from secrets import token_hex

from fastapi import Depends, FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .db import Base, engine, get_db
from .models import DailyAssignment, Group, Membership, User
from .realtime import manager
from .schemas import (
    ApprovalRequest,
    AssignmentComplete,
    GroupCreate,
    GroupStatus,
    GroupStatusItem,
    JoinGroup,
    ManualJuzChange,
    TodayGroupItem,
    UserCreate,
)

app = FastAPI(title="Khatma Daily API", version="0.3.0")


@app.on_event("startup")
def startup() -> None:
    Base.metadata.create_all(bind=engine)


def _active_memberships(db: Session, group_id: int):
    return db.scalars(
        select(Membership)
        .where(
            Membership.group_id == group_id,
            Membership.active.is_(True),
            Membership.status == "active",
            Membership.participates_in_reading.is_(True),
        )
        .order_by(Membership.id)
    ).all()


def _ensure_today_assignments(db: Session, group: Group) -> int:
    memberships = _active_memberships(db, group.id)
    today = date.today()
    day_offset = max((today - group.created_at.date()).days, 0)
    created = 0
    for index, membership in enumerate(memberships):
        exists = db.scalar(
            select(DailyAssignment).where(
                DailyAssignment.group_id == group.id,
                DailyAssignment.membership_id == membership.id,
                DailyAssignment.reading_date == today,
            )
        )
        if exists:
            continue
        # Rotate the Juz daily while preserving 30-member khatma buckets.
        juz = ((index + day_offset) % 30) + 1
        db.add(
            DailyAssignment(
                group_id=group.id,
                membership_id=membership.id,
                reading_date=today,
                khatma_number=(index // 30) + 1,
                juz_number=juz,
            )
        )
        created += 1
    if created:
        db.commit()
    return created


def _leader_membership(db: Session, group_id: int, user_id: int):
    membership = db.scalar(
        select(Membership).where(
            Membership.group_id == group_id,
            Membership.user_id == user_id,
            Membership.status == "active",
            Membership.active.is_(True),
        )
    )
    if not membership or membership.role not in {"leader", "assistant"}:
        raise HTTPException(status_code=403, detail="Leader permission required")
    return membership


@app.get("/health")
def health():
    return {"status": "ok", "version": "0.3.0"}


@app.post("/users")
def create_user(payload: UserCreate, db: Session = Depends(get_db)):
    user = User(name=payload.name.strip())
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"id": user.id, "name": user.name}


@app.post("/groups")
def create_group(payload: GroupCreate, db: Session = Depends(get_db)):
    user = db.get(User, payload.leader_user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    code = token_hex(3).upper()
    while db.scalar(select(Group).where(Group.invite_code == code)):
        code = token_hex(3).upper()

    group = Group(
        name=payload.name.strip(),
        invite_code=code,
        require_approval=payload.require_approval,
    )
    db.add(group)
    db.flush()
    db.add(Membership(
        group_id=group.id,
        user_id=user.id,
        role="leader",
        status="active",
        participates_in_reading=payload.leader_participates,
    ))
    db.commit()
    db.refresh(group)
    _ensure_today_assignments(db, group)
    return {
        "id": group.id,
        "name": group.name,
        "invite_code": group.invite_code,
        "require_approval": group.require_approval,
    }


@app.post("/groups/join")
def join_group(payload: JoinGroup, db: Session = Depends(get_db)):
    group = db.scalar(select(Group).where(func.upper(Group.invite_code) == payload.invite_code.strip().upper()))
    if not group:
        raise HTTPException(status_code=404, detail="Invite code not found")
    if not db.get(User, payload.user_id):
        raise HTTPException(status_code=404, detail="User not found")

    existing = db.scalar(
        select(Membership).where(Membership.group_id == group.id, Membership.user_id == payload.user_id)
    )
    if existing:
        return {
            "group_id": group.id,
            "group_name": group.name,
            "membership_id": existing.id,
            "status": existing.status,
        }

    status = "pending" if group.require_approval else "active"
    membership = Membership(group_id=group.id, user_id=payload.user_id, role="member", status=status)
    db.add(membership)
    db.commit()
    db.refresh(membership)
    if status == "active":
        _ensure_today_assignments(db, group)
    return {
        "group_id": group.id,
        "group_name": group.name,
        "membership_id": membership.id,
        "status": membership.status,
    }


@app.post("/groups/{group_id}/members/{membership_id}/approval")
def approve_member(group_id: int, membership_id: int, payload: ApprovalRequest, db: Session = Depends(get_db)):
    _leader_membership(db, group_id, payload.leader_user_id)
    membership = db.get(Membership, membership_id)
    if not membership or membership.group_id != group_id:
        raise HTTPException(status_code=404, detail="Membership not found")
    membership.status = "active" if payload.approve else "rejected"
    membership.active = payload.approve
    db.commit()
    group = db.get(Group, group_id)
    if payload.approve and group:
        _ensure_today_assignments(db, group)
    return {"ok": True, "status": membership.status}


@app.post("/groups/{group_id}/assign-today")
def assign_today(group_id: int, leader_user_id: int, db: Session = Depends(get_db)):
    _leader_membership(db, group_id, leader_user_id)
    group = db.get(Group, group_id)
    if not group:
        raise HTTPException(status_code=404, detail="Group not found")
    created = _ensure_today_assignments(db, group)
    return {"group_id": group_id, "date": date.today(), "created": created}


@app.get("/users/{user_id}/today", response_model=list[TodayGroupItem])
def user_today(user_id: int, db: Session = Depends(get_db)):
    memberships = db.scalars(
        select(Membership)
        .where(Membership.user_id == user_id, Membership.active.is_(True))
        .order_by(Membership.id)
    ).all()
    result: list[TodayGroupItem] = []
    for membership in memberships:
        group = db.get(Group, membership.group_id)
        if not group:
            continue
        if membership.status == "active":
            _ensure_today_assignments(db, group)
        assignment = db.scalar(
            select(DailyAssignment).where(
                DailyAssignment.membership_id == membership.id,
                DailyAssignment.reading_date == date.today(),
            )
        )
        total = db.scalar(
            select(func.count(DailyAssignment.id)).where(
                DailyAssignment.group_id == group.id,
                DailyAssignment.reading_date == date.today(),
            )
        ) or 0
        completed = db.scalar(
            select(func.count(DailyAssignment.id)).where(
                DailyAssignment.group_id == group.id,
                DailyAssignment.reading_date == date.today(),
                DailyAssignment.completed.is_(True),
            )
        ) or 0
        result.append(
            TodayGroupItem(
                group_id=group.id,
                group_name=group.name,
                role=membership.role,
                membership_status=membership.status,
                assignment_id=assignment.id if assignment else None,
                khatma_number=assignment.khatma_number if assignment else None,
                juz_number=assignment.juz_number if assignment else None,
                completed=bool(assignment and assignment.completed),
                completed_count=completed,
                total_count=total,
            )
        )
    return result


@app.post("/assignments/{assignment_id}/complete")
async def complete_reading(assignment_id: int, payload: AssignmentComplete, db: Session = Depends(get_db)):
    assignment = db.get(DailyAssignment, assignment_id)
    if not assignment:
        raise HTTPException(status_code=404, detail="Assignment not found")
    membership = db.get(Membership, assignment.membership_id)
    if not membership or membership.user_id != payload.user_id:
        raise HTTPException(status_code=403, detail="This assignment does not belong to the user")

    assignment.completed = True
    assignment.completed_at = datetime.utcnow()
    db.commit()
    await manager.broadcast(
        assignment.group_id,
        {
            "type": "reading_completed",
            "group_id": assignment.group_id,
            "membership_id": assignment.membership_id,
            "assignment_id": assignment.id,
            "reading_date": str(assignment.reading_date),
        },
    )
    return {"ok": True}


@app.post("/groups/{group_id}/assignments/{membership_id}/juz")
async def change_member_juz(
    group_id: int, membership_id: int, payload: ManualJuzChange, db: Session = Depends(get_db)
):
    _leader_membership(db, group_id, payload.leader_user_id)
    assignment = db.scalar(
        select(DailyAssignment).where(
            DailyAssignment.group_id == group_id,
            DailyAssignment.membership_id == membership_id,
            DailyAssignment.reading_date == date.today(),
        )
    )
    if not assignment:
        raise HTTPException(status_code=404, detail="Today's assignment not found")
    if assignment.completed:
        raise HTTPException(status_code=409, detail="Completed assignment cannot be changed")

    old_juz = assignment.juz_number
    other = db.scalar(
        select(DailyAssignment).where(
            DailyAssignment.group_id == group_id,
            DailyAssignment.reading_date == date.today(),
            DailyAssignment.khatma_number == assignment.khatma_number,
            DailyAssignment.juz_number == payload.juz_number,
            DailyAssignment.id != assignment.id,
        )
    )
    assignment.juz_number = payload.juz_number
    if other:
        if other.completed:
            raise HTTPException(status_code=409, detail="Target Juz is already completed by another member")
        other.juz_number = old_juz
    db.commit()

    await manager.broadcast(
        group_id,
        {
            "type": "assignment_changed",
            "group_id": group_id,
            "membership_id": membership_id,
            "juz_number": payload.juz_number,
        },
    )
    return {"ok": True, "swapped": other is not None, "juz_number": payload.juz_number}


@app.get("/groups/{group_id}/status", response_model=GroupStatus)
def group_status(group_id: int, user_id: int, reading_date: date | None = None, db: Session = Depends(get_db)):
    _leader_membership(db, group_id, user_id)
    group = db.get(Group, group_id)
    if not group:
        raise HTTPException(status_code=404, detail="Group not found")
    target_date = reading_date or date.today()
    if target_date == date.today():
        _ensure_today_assignments(db, group)

    memberships = db.execute(
        select(Membership, User)
        .join(User, User.id == Membership.user_id)
        .where(Membership.group_id == group_id, Membership.active.is_(True))
        .order_by(Membership.id)
    ).all()

    items: list[GroupStatusItem] = []
    for membership, user in memberships:
        assignment = db.scalar(
            select(DailyAssignment).where(
                DailyAssignment.membership_id == membership.id,
                DailyAssignment.reading_date == target_date,
            )
        )
        items.append(
            GroupStatusItem(
                membership_id=membership.id,
                user_id=user.id,
                member_name=user.name,
                role=membership.role,
                khatma_number=assignment.khatma_number if assignment else None,
                juz_number=assignment.juz_number if assignment else None,
                completed=bool(assignment and assignment.completed),
            )
        )

    reading_items = [i for i in items if i.juz_number is not None]
    pending_count = db.scalar(
        select(func.count(Membership.id)).where(Membership.group_id == group_id, Membership.status == "pending")
    ) or 0
    return GroupStatus(
        group_id=group_id,
        group_name=group.name,
        invite_code=group.invite_code,
        reading_date=target_date,
        completed_count=sum(1 for item in reading_items if item.completed),
        total_count=len(reading_items),
        pending_count=pending_count,
        members=items,
    )


@app.get("/groups/{group_id}/pending")
def pending_members(group_id: int, user_id: int, db: Session = Depends(get_db)):
    _leader_membership(db, group_id, user_id)
    rows = db.execute(
        select(Membership, User)
        .join(User, User.id == Membership.user_id)
        .where(Membership.group_id == group_id, Membership.status == "pending")
        .order_by(Membership.joined_at)
    ).all()
    return [
        {"membership_id": membership.id, "user_id": user.id, "name": user.name}
        for membership, user in rows
    ]


@app.websocket("/ws/groups/{group_id}")
async def group_socket(group_id: int, websocket: WebSocket):
    await manager.connect(group_id, websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(group_id, websocket)
