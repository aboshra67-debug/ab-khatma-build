from datetime import date
from pydantic import BaseModel, Field


class UserCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)


class GroupCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    leader_user_id: int
    require_approval: bool = True
    leader_participates: bool = False


class JoinGroup(BaseModel):
    invite_code: str = Field(min_length=4, max_length=16)
    user_id: int


class ApprovalRequest(BaseModel):
    leader_user_id: int
    approve: bool = True


class AssignmentComplete(BaseModel):
    user_id: int


class ManualJuzChange(BaseModel):
    leader_user_id: int
    juz_number: int = Field(ge=1, le=30)


class TodayGroupItem(BaseModel):
    group_id: int
    group_name: str
    role: str
    membership_status: str
    assignment_id: int | None = None
    khatma_number: int | None = None
    juz_number: int | None = None
    completed: bool = False
    completed_count: int = 0
    total_count: int = 0


class GroupStatusItem(BaseModel):
    membership_id: int
    user_id: int
    member_name: str
    role: str
    khatma_number: int | None
    juz_number: int | None
    completed: bool


class GroupStatus(BaseModel):
    group_id: int
    group_name: str
    invite_code: str
    reading_date: date
    completed_count: int
    total_count: int
    pending_count: int
    members: list[GroupStatusItem]
