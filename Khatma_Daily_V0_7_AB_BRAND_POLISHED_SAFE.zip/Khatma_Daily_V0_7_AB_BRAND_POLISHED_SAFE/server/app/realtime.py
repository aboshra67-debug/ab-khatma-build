from collections import defaultdict
from fastapi import WebSocket


class ConnectionManager:
    def __init__(self):
        self._groups: dict[int, set[WebSocket]] = defaultdict(set)

    async def connect(self, group_id: int, websocket: WebSocket):
        await websocket.accept()
        self._groups[group_id].add(websocket)

    def disconnect(self, group_id: int, websocket: WebSocket):
        self._groups[group_id].discard(websocket)
        if not self._groups[group_id]:
            self._groups.pop(group_id, None)

    async def broadcast(self, group_id: int, payload: dict):
        dead = []
        for websocket in self._groups.get(group_id, set()):
            try:
                await websocket.send_json(payload)
            except Exception:
                dead.append(websocket)
        for websocket in dead:
            self.disconnect(group_id, websocket)


manager = ConnectionManager()
