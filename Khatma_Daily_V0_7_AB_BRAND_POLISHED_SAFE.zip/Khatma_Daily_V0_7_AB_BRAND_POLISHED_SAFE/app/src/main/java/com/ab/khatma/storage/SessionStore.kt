package com.ab.khatma.storage

import android.content.Context

class SessionStore(context: Context) {
    private val prefs = context.getSharedPreferences("khatma_session", Context.MODE_PRIVATE)

    fun userId(): Long = prefs.getLong("user_id", 0L)
    fun userName(): String = prefs.getString("user_name", "") ?: ""

    fun saveUser(id: Long, name: String) {
        prefs.edit().putLong("user_id", id).putString("user_name", name).apply()
    }

    fun clear() {
        prefs.edit().clear().apply()
    }
}
