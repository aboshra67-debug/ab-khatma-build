package com.ab.khatma.offline

import android.content.Context
import com.ab.khatma.network.ApiClient
import com.ab.khatma.storage.SessionStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Single synchronization path used by background workers.
 * Pending local completions are sent before today's snapshot is refreshed,
 * so a local "completed" action can never be overwritten by an older server snapshot.
 */
object OfflineSyncEngine {
    suspend fun sync(context: Context): Boolean = withContext(Dispatchers.IO) {
        val store = OfflineStore(context)
        var failed = false

        store.pendingCompletions().forEach { item ->
            runCatching { ApiClient.completeAssignment(item.assignmentId, item.userId) }
                .onSuccess { store.removePending(item.assignmentId) }
                .onFailure { failed = true }
        }

        val userId = SessionStore(context).userId()
        if (userId > 0) {
            runCatching { ApiClient.today(userId) }
                .onSuccess(store::saveGroups)
                .onFailure { failed = true }
        }
        !failed
    }
}
