package com.ab.khatma.network

import com.ab.khatma.BuildConfig
import com.ab.khatma.model.GroupCreated
import com.ab.khatma.model.LeaderMember
import com.ab.khatma.model.LeaderStatus
import com.ab.khatma.model.TodayGroup
import com.ab.khatma.model.PendingMember
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

object ApiClient {
    private fun request(path: String, method: String = "GET", body: JSONObject? = null): String {
        val connection = (URL(BuildConfig.API_BASE_URL.trimEnd('/') + path).openConnection() as HttpURLConnection)
        connection.requestMethod = method
        connection.connectTimeout = 10_000
        connection.readTimeout = 10_000
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        if (body != null) {
            connection.doOutput = true
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.use { input ->
            BufferedReader(InputStreamReader(input)).readText()
        }.orEmpty()
        connection.disconnect()
        if (code !in 200..299) {
            val message = runCatching { JSONObject(text).optString("detail") }.getOrNull()
            throw IllegalStateException(message?.takeIf { it.isNotBlank() } ?: "HTTP $code")
        }
        return text
    }

    fun createUser(name: String): Pair<Long, String> {
        val json = JSONObject(request("/users", "POST", JSONObject().put("name", name)))
        return json.getLong("id") to json.getString("name")
    }

    fun today(userId: Long): List<TodayGroup> {
        val arr = JSONArray(request("/users/$userId/today"))
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(
                    TodayGroup(
                        groupId = o.getLong("group_id"),
                        groupName = o.getString("group_name"),
                        role = o.getString("role"),
                        membershipStatus = o.getString("membership_status"),
                        assignmentId = o.optLongOrNull("assignment_id"),
                        khatmaNumber = o.optIntOrNull("khatma_number"),
                        juzNumber = o.optIntOrNull("juz_number"),
                        completed = o.optBoolean("completed", false),
                        completedCount = o.optInt("completed_count", 0),
                        totalCount = o.optInt("total_count", 0),
                    )
                )
            }
        }
    }

    fun createGroup(name: String, userId: Long, leaderParticipates: Boolean): GroupCreated {
        val payload = JSONObject()
            .put("name", name)
            .put("leader_user_id", userId)
            .put("require_approval", true)
            .put("leader_participates", leaderParticipates)
        val o = JSONObject(request("/groups", "POST", payload))
        return GroupCreated(o.getLong("id"), o.getString("name"), o.getString("invite_code"))
    }

    fun joinGroup(code: String, userId: Long): String {
        val payload = JSONObject().put("invite_code", code).put("user_id", userId)
        return JSONObject(request("/groups/join", "POST", payload)).getString("status")
    }

    fun completeAssignment(assignmentId: Long, userId: Long) {
        request("/assignments/$assignmentId/complete", "POST", JSONObject().put("user_id", userId))
    }

    fun pendingMembers(groupId: Long, userId: Long): List<PendingMember> {
        val arr = JSONArray(request("/groups/$groupId/pending?user_id=$userId"))
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(PendingMember(o.getLong("membership_id"), o.getLong("user_id"), o.getString("name")))
            }
        }
    }

    fun approveMember(groupId: Long, membershipId: Long, leaderUserId: Long, approve: Boolean) {
        val payload = JSONObject().put("leader_user_id", leaderUserId).put("approve", approve)
        request("/groups/$groupId/members/$membershipId/approval", "POST", payload)
    }

    fun changeMemberJuz(groupId: Long, membershipId: Long, leaderUserId: Long, juz: Int) {
        val payload = JSONObject().put("leader_user_id", leaderUserId).put("juz_number", juz)
        request("/groups/$groupId/assignments/$membershipId/juz", "POST", payload)
    }

    fun leaderStatus(groupId: Long, userId: Long): LeaderStatus {
        val o = JSONObject(request("/groups/$groupId/status?user_id=$userId"))
        val arr = o.getJSONArray("members")
        val members = buildList {
            for (i in 0 until arr.length()) {
                val m = arr.getJSONObject(i)
                add(
                    LeaderMember(
                        membershipId = m.getLong("membership_id"),
                        userId = m.getLong("user_id"),
                        name = m.getString("member_name"),
                        role = m.getString("role"),
                        khatmaNumber = m.optIntOrNull("khatma_number"),
                        juzNumber = m.optIntOrNull("juz_number"),
                        completed = m.optBoolean("completed", false),
                    )
                )
            }
        }
        return LeaderStatus(
            groupId = o.getLong("group_id"),
            groupName = o.getString("group_name"),
            inviteCode = o.getString("invite_code"),
            completedCount = o.getInt("completed_count"),
            totalCount = o.getInt("total_count"),
            pendingCount = o.getInt("pending_count"),
            members = members,
        )
    }

    private fun JSONObject.optLongOrNull(key: String): Long? =
        if (isNull(key) || !has(key)) null else getLong(key)

    private fun JSONObject.optIntOrNull(key: String): Int? =
        if (isNull(key) || !has(key)) null else getInt(key)
}
