package com.ab.khatma.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.GroupAdd
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ab.khatma.R
import com.ab.khatma.model.TodayGroup

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    userName: String,
    groups: List<TodayGroup>,
    loading: Boolean,
    isOffline: Boolean,
    onRefresh: () -> Unit,
    onCreateGroup: () -> Unit,
    onJoinGroup: () -> Unit,
    onComplete: (TodayGroup) -> Unit,
    onLeaderOpen: (Long) -> Unit,
    onOpenQuran: (Int?) -> Unit,
    onOpenPrayerSettings: () -> Unit,
    onOpenAppearance: () -> Unit,
) {
    val activeGroups = groups.filter { it.membershipStatus == "active" }
    val completedGroups = activeGroups.count { it.completed }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(R.drawable.ab_khatma_mark),
                            contentDescription = "شعار AB ختمة",
                            modifier = Modifier.size(42.dp),
                            contentScale = ContentScale.Fit,
                        )
                        Spacer(Modifier.width(8.dp))
                        Text("ختمة", fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                    actionIconContentColor = MaterialTheme.colorScheme.onBackground,
                ),
                actions = {
                    IconButton(onClick = onOpenAppearance) {
                        Icon(Icons.Rounded.Palette, contentDescription = "الثيمات")
                    }
                    IconButton(onClick = onOpenPrayerSettings) {
                        Icon(Icons.Rounded.Notifications, contentDescription = "التنبيهات")
                    }
                    IconButton(onClick = onRefresh) {
                        Icon(Icons.Rounded.Refresh, contentDescription = "تحديث")
                    }
                },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp),
        ) {
            item {
                Spacer(Modifier.height(4.dp))
                HeroTodayCard(
                    userName = userName,
                    activeCount = activeGroups.size,
                    completedCount = completedGroups,
                    onOpenQuran = { onOpenQuran(null) },
                )
            }

            if (isOffline) {
                item {
                    AssistChip(
                        onClick = onRefresh,
                        label = { Text("بدون إنترنت — الإنجاز محفوظ وسيُزامن تلقائيًا") },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer,
                            labelColor = MaterialTheme.colorScheme.onSecondaryContainer,
                        ),
                    )
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onCreateGroup,
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 14.dp),
                    ) {
                        Text("إنشاء مجموعة")
                    }
                    OutlinedButton(
                        onClick = onJoinGroup,
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 14.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    ) {
                        Icon(Icons.Rounded.GroupAdd, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("انضمام")
                    }
                }
            }

            if (loading) item { LinearProgressIndicator(modifier = Modifier.fillMaxWidth()) }

            if (groups.isEmpty() && !loading) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    ) {
                        Column(Modifier.padding(20.dp)) {
                            Text("ابدأ أول ختمة", style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "أنشئ مجموعة جديدة أو انضم بكود مجموعة، وبعدها سيظهر جزؤك اليومي هنا.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }

            items(groups, key = { it.groupId }) { group ->
                GroupReadingCard(group, onComplete, onLeaderOpen, onOpenQuran)
            }

            item {
                Text("أدوات سريعة", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    QuickActionCard(
                        title = "المصحف",
                        icon = { Icon(Icons.Rounded.MenuBook, contentDescription = null) },
                        onClick = { onOpenQuran(null) },
                        modifier = Modifier.weight(1f),
                    )
                    QuickActionCard(
                        title = "التنبيهات",
                        icon = { Icon(Icons.Rounded.Notifications, contentDescription = null) },
                        onClick = onOpenPrayerSettings,
                        modifier = Modifier.weight(1f),
                    )
                    QuickActionCard(
                        title = "الثيمات",
                        icon = { Icon(Icons.Rounded.Palette, contentDescription = null) },
                        onClick = onOpenAppearance,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

@Composable
private fun HeroTodayCard(
    userName: String,
    activeCount: Int,
    completedCount: Int,
    onOpenQuran: () -> Unit,
) {
    val total = activeCount.coerceAtLeast(1)
    val progress = if (activeCount == 0) 0f else completedCount.toFloat() / total

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)),
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "السلام عليكم${if (userName.isNotBlank()) " $userName" else ""}",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (activeCount == 0) "اليوم فرصة جديدة للبدء مع القرآن"
                        else "تقدمك اليوم: $completedCount من $activeCount أجزاء مطلوبة أُنجزت",
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.82f),
                    )
                }
                Image(
                    painter = painterResource(R.drawable.ab_khatma_mark),
                    contentDescription = "AB ختمة",
                    modifier = Modifier.size(88.dp),
                    contentScale = ContentScale.Fit,
                )
            }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.weight(1f).height(8.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.55f),
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    "${(progress * 100).toInt()}%",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onOpenQuran,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                ),
            ) {
                Icon(Icons.Rounded.MenuBook, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("فتح المصحف")
            }
        }
    }
}

@Composable
private fun QuickActionCard(
    title: String,
    icon: @Composable () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        onClick = onClick,
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            CompositionLocalProvider(LocalContentColor provides MaterialTheme.colorScheme.primary) { icon() }
            Spacer(Modifier.height(6.dp))
            Text(title, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
private fun GroupReadingCard(
    group: TodayGroup,
    onComplete: (TodayGroup) -> Unit,
    onLeaderOpen: (Long) -> Unit,
    onOpenQuran: (Int?) -> Unit,
) {
    val completedContainer = if (group.completed) {
        MaterialTheme.colorScheme.tertiaryContainer
    } else {
        MaterialTheme.colorScheme.surface
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = completedContainer),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(group.groupName, style = MaterialTheme.typography.titleLarge)
                    if (group.membershipStatus == "pending") {
                        Spacer(Modifier.height(3.dp))
                        Text("بانتظار موافقة القائد", color = MaterialTheme.colorScheme.secondary)
                    } else {
                        Spacer(Modifier.height(3.dp))
                        Text(
                            "جزؤك اليوم: ${group.juzNumber?.let { "الجزء $it" } ?: "لم يوزع بعد"}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        if ((group.khatmaNumber ?: 1) > 1) {
                            Text("الختمة رقم ${group.khatmaNumber}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                if (group.completed) {
                    Icon(
                        Icons.Rounded.CheckCircle,
                        contentDescription = "تم",
                        tint = MaterialTheme.colorScheme.tertiary,
                    )
                }
            }

            if (group.membershipStatus == "active") {
                Spacer(Modifier.height(14.dp))
                val progress = if (group.totalCount == 0) 0f else group.completedCount.toFloat() / group.totalCount
                Text(
                    "تقدم المجموعة: ${group.completedCount} من ${group.totalCount}",
                    style = MaterialTheme.typography.bodyMedium,
                )
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().padding(top = 7.dp).height(7.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                )
                Spacer(Modifier.height(14.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onOpenQuran(group.juzNumber) },
                        modifier = Modifier.weight(1f),
                        enabled = group.juzNumber != null,
                    ) {
                        Text("ابدأ الجزء")
                    }
                    OutlinedButton(
                        onClick = { onComplete(group) },
                        modifier = Modifier.weight(1f),
                        enabled = !group.completed && group.assignmentId != null,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                    ) {
                        Text(if (group.completed) "تمت القراءة ✓" else "تمت القراءة")
                    }
                }

                Text(
                    "يمكنك تسجيل الإتمام حتى لو قرأت من مصحف ورقي.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 7.dp),
                )

                if (group.role == "leader" || group.role == "assistant") {
                    Spacer(Modifier.height(6.dp))
                    TextButton(onClick = { onLeaderOpen(group.groupId) }, modifier = Modifier.fillMaxWidth()) {
                        Text("متابعة المجموعة")
                    }
                }
            }
        }
    }
}
