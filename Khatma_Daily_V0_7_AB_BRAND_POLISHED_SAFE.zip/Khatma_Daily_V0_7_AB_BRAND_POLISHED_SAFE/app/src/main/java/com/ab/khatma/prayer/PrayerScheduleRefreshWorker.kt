package com.ab.khatma.prayer

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class PrayerScheduleRefreshWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        PrayerNotificationScheduler.scheduleRollingWindow(applicationContext)
        return Result.success()
    }
}
