package com.ab.khatma.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ab.khatma.R

@Composable
fun BrandSplashScreen() {
    val gold = Color(0xFFF3C45B)
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF020817),
                        Color(0xFF061A3D),
                        Color(0xFF0A2451),
                    ),
                ),
            ),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Image(
                painter = painterResource(R.drawable.ab_khatma_logo_full),
                contentDescription = "AB ختمة",
                modifier = Modifier.size(285.dp),
                contentScale = ContentScale.Fit,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "نقرأ، نتدبر، ونختم كتاب الله معًا",
                color = Color(0xFFF7F2E8),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(22.dp))
            CircularProgressIndicator(
                color = gold,
                trackColor = Color.White.copy(alpha = 0.14f),
                strokeWidth = 3.dp,
                modifier = Modifier.size(30.dp),
            )
        }
    }
}
