package com.ab.khatma.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import com.ab.khatma.model.LeaderMember
import com.ab.khatma.model.LeaderStatus
import com.ab.khatma.model.PendingMember

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeaderGroupScreen(
    status: LeaderStatus?,
    pending: List<PendingMember>,
    loading: Boolean,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
    onApprove: (Long, Boolean) -> Unit,
    onChangeJuz: (Long, Int) -> Unit,
) {
    var selectedMember by remember { mutableStateOf<LeaderMember?>(null) }
    var juzText by remember { mutableStateOf("") }

    selectedMember?.let { member ->
        AlertDialog(
            onDismissRequest = { selectedMember = null },
            title = { Text("تغيير الجزء — ${member.name}") },
            text = {
                Column {
                    Text("لو الجزء المختار مع عضو آخر في نفس الختمة، سيتم تبديل الجزأين تلقائيًا.")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = juzText,
                        onValueChange = { value -> juzText = value.filter(Char::isDigit).take(2) },
                        label = { Text("رقم الجزء من 1 إلى 30") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    )
                }
            },
            confirmButton = {
                val juz = juzText.toIntOrNull()
                Button(
                    onClick = {
                        if (juz != null) onChangeJuz(member.membershipId, juz)
                        selectedMember = null
                    },
                    enabled = juz != null && juz in 1..30,
                ) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { selectedMember = null }) { Text("إلغاء") } },
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("متابعة المجموعة") },
                navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } },
                actions = { TextButton(onClick = onRefresh) { Text("تحديث") } },
            )
        },
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            if (loading && status == null) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                return@Column
            }
            if (status == null) {
                Text("لا توجد بيانات")
                return@Column
            }
            Text(status.groupName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("كود الدعوة: ${status.inviteCode}", fontWeight = FontWeight.SemiBold)
            Text("${status.completedCount} من ${status.totalCount} أتموا القراءة")
            val progress = if (status.totalCount == 0) 0f else status.completedCount.toFloat() / status.totalCount
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (pending.isNotEmpty()) {
                    item { Text("طلبات الانضمام (${pending.size})", fontWeight = FontWeight.Bold) }
                    items(pending, key = { "p_${it.membershipId}" }) { member ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(member.name, fontWeight = FontWeight.SemiBold)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { onApprove(member.membershipId, true) }) { Text("قبول") }
                                    OutlinedButton(onClick = { onApprove(member.membershipId, false) }) { Text("رفض") }
                                }
                            }
                        }
                    }
                    item { HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp)) }
                }

                item { Text("أعضاء المجموعة", fontWeight = FontWeight.Bold) }
                items(status.members, key = { it.membershipId }) { member ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text(member.name, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        if (member.juzNumber != null) "الجزء ${member.juzNumber} — ختمة ${member.khatmaNumber ?: 1}"
                                        else if (member.role == "leader") "القائد — غير مشارك في قراءة اليوم" else "لم يوزع جزء"
                                    )
                                }
                                if (member.juzNumber != null) Text(if (member.completed) "✅ تم" else "⏳ لم يتم")
                            }
                            if (member.juzNumber != null && !member.completed) {
                                TextButton(onClick = {
                                    selectedMember = member
                                    juzText = member.juzNumber.toString()
                                }) { Text("تغيير الجزء") }
                            }
                        }
                    }
                }
            }
        }
    }
}
