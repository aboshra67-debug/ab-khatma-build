package com.ab.khatma.prayer

import android.Manifest
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.ab.khatma.MainActivity
import com.ab.khatma.offline.OfflineStore
import com.ab.khatma.offline.OfflineSyncEngine

class PrayerReminderWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val store = OfflineStore(applicationContext)
        // Send pending completions first, then fetch today's fresh assignments.
        // If the device is offline the locally cached snapshot remains authoritative.
        OfflineSyncEngine.sync(applicationContext)

        val remaining = store.incompleteGroups()
        if (remaining.isEmpty()) return Result.success()
        if (
            Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return Result.success()

        val prayer = inputData.getString("prayer_name") ?: "الصلاة"
        val prayerSettings = PrayerSettingsStore(applicationContext).load()
        val stillEnabled = when (prayer) {
            "الفجر" -> prayerSettings.fajr
            "الظهر" -> prayerSettings.dhuhr
            "العصر" -> prayerSettings.asr
            "المغرب" -> prayerSettings.maghrib
            "العشاء" -> prayerSettings.isha
            else -> false
        }
        if (!stillEnabled) return Result.success()

        val details = remaining.take(3).joinToString(" • ") { g ->
            "${g.groupName}: ${g.juzNumber?.let { "الجزء $it" } ?: "جزء اليوم"}"
        }
        val text = if (remaining.size > 3) "$details • و${remaining.size - 3} مجموعة أخرى" else details

        val openApp = PendingIntent.getActivity(
            applicationContext,
            1001,
            Intent(applicationContext, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notification = NotificationCompat.Builder(applicationContext, PrayerNotificationScheduler.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("بعد $prayer — لم يكتمل جزء اليوم")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .build()
        val id = ("$prayer-${System.currentTimeMillis() / 86_400_000L}").hashCode()
        applicationContext.getSystemService(NotificationManager::class.java).notify(id, notification)
        return Result.success()
    }
}
