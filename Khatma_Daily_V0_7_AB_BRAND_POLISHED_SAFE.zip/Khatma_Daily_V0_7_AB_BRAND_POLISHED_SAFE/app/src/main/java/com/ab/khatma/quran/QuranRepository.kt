package com.ab.khatma.quran

import android.content.Context
import org.json.JSONArray

data class QuranAyah(val surah: Int, val ayah: Int, val text: String, val juz: Int, val page: Int)

class QuranRepository(private val context: Context) {
    fun isBundled(): Boolean = runCatching { context.assets.open("quran/quran-uthmani.json").close(); true }.getOrDefault(false)

    fun loadJuz(juz: Int): List<QuranAyah> {
        if (!isBundled()) return emptyList()
        val text = context.assets.open("quran/quran-uthmani.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(text)
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.getInt("juz") == juz) {
                    add(QuranAyah(o.getInt("surah"), o.getInt("ayah"), o.getString("text"), juz, o.getInt("page")))
                }
            }
        }
    }
}
