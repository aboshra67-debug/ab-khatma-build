package com.ab.khatma.prayer

import com.batoulapps.adhan2.CalculationMethod
import com.batoulapps.adhan2.Coordinates
import com.batoulapps.adhan2.PrayerTimes
import com.batoulapps.adhan2.data.DateComponents
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class DailyPrayerTimes(
    val date: LocalDate,
    val fajr: Long,
    val dhuhr: Long,
    val asr: Long,
    val maghrib: Long,
    val isha: Long,
) {
    fun entries(): List<Pair<String, Long>> = listOf(
        "الفجر" to fajr,
        "الظهر" to dhuhr,
        "العصر" to asr,
        "المغرب" to maghrib,
        "العشاء" to isha,
    )
}

object PrayerCalculator {
    fun calculate(location: PrayerLocation, date: LocalDate): DailyPrayerTimes {
        val coordinates = Coordinates(location.latitude, location.longitude)
        val components = DateComponents(date.year, date.monthValue, date.dayOfMonth)
        val params = CalculationMethod.EGYPTIAN.parameters
        val times = PrayerTimes(coordinates, components, params)
        return DailyPrayerTimes(
            date,
            times.fajr.toEpochMilliseconds(),
            times.dhuhr.toEpochMilliseconds(),
            times.asr.toEpochMilliseconds(),
            times.maghrib.toEpochMilliseconds(),
            times.isha.toEpochMilliseconds(),
        )
    }

    fun format(epochMillis: Long, timeZoneId: String = TimeZone.getDefault().id): String {
        val formatter = SimpleDateFormat("hh:mm a", Locale("ar", "EG"))
        formatter.timeZone = TimeZone.getTimeZone(timeZoneId)
        return formatter.format(Date(epochMillis))
    }
}
