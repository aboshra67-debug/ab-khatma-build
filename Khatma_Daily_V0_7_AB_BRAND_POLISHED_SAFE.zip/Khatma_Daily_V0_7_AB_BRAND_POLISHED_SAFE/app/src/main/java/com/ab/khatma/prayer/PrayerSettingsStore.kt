package com.ab.khatma.prayer

import android.content.Context

data class PrayerLocation(val name: String, val latitude: Double, val longitude: Double, val timeZoneId: String = "Africa/Cairo")

data class PrayerSettings(
    val location: PrayerLocation,
    val delayMinutes: Int,
    val fajr: Boolean,
    val dhuhr: Boolean,
    val asr: Boolean,
    val maghrib: Boolean,
    val isha: Boolean,
)

class PrayerSettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("khatma_prayer_settings", Context.MODE_PRIVATE)

    fun load(): PrayerSettings = PrayerSettings(
        location = PrayerLocation(
            prefs.getString("location_name", "القاهرة") ?: "القاهرة",
            java.lang.Double.longBitsToDouble(prefs.getLong("latitude", java.lang.Double.doubleToRawLongBits(30.0444))),
            java.lang.Double.longBitsToDouble(prefs.getLong("longitude", java.lang.Double.doubleToRawLongBits(31.2357))),
            prefs.getString("time_zone", "Africa/Cairo") ?: "Africa/Cairo",
        ),
        delayMinutes = prefs.getInt("delay", 15),
        fajr = prefs.getBoolean("fajr", true),
        dhuhr = prefs.getBoolean("dhuhr", true),
        asr = prefs.getBoolean("asr", true),
        maghrib = prefs.getBoolean("maghrib", true),
        isha = prefs.getBoolean("isha", true),
    )

    fun save(settings: PrayerSettings) {
        prefs.edit()
            .putString("location_name", settings.location.name)
            .putLong("latitude", java.lang.Double.doubleToRawLongBits(settings.location.latitude))
            .putLong("longitude", java.lang.Double.doubleToRawLongBits(settings.location.longitude))
            .putString("time_zone", settings.location.timeZoneId)
            .putInt("delay", settings.delayMinutes)
            .putBoolean("fajr", settings.fajr)
            .putBoolean("dhuhr", settings.dhuhr)
            .putBoolean("asr", settings.asr)
            .putBoolean("maghrib", settings.maghrib)
            .putBoolean("isha", settings.isha)
            .apply()
    }
}

object EgyptCities {
    val all = listOf(
        PrayerLocation("القاهرة", 30.0444, 31.2357),
        PrayerLocation("الجيزة", 30.0131, 31.2089),
        PrayerLocation("الإسكندرية", 31.2001, 29.9187),
        PrayerLocation("المنصورة", 31.0409, 31.3785),
        PrayerLocation("طنطا", 30.7865, 31.0004),
        PrayerLocation("الزقازيق", 30.5877, 31.5020),
        PrayerLocation("الإسماعيلية", 30.5965, 32.2715),
        PrayerLocation("السويس", 29.9668, 32.5498),
        PrayerLocation("بورسعيد", 31.2653, 32.3019),
        PrayerLocation("العريش", 31.1321, 33.8033),
        PrayerLocation("شرم الشيخ", 27.9158, 34.3300),
        PrayerLocation("الطور", 28.2417, 33.6222),
        PrayerLocation("رأس سدر", 29.5920, 32.7150),
        PrayerLocation("أسيوط", 27.1809, 31.1837),
        PrayerLocation("سوهاج", 26.5591, 31.6957),
        PrayerLocation("قنا", 26.1551, 32.7160),
        PrayerLocation("الأقصر", 25.6872, 32.6396),
        PrayerLocation("أسوان", 24.0889, 32.8998),
    )
}
