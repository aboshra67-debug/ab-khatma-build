package com.ab.khatma.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.ab.khatma.prayer.*
import java.time.LocalDate
import java.time.ZoneId
import java.util.TimeZone

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrayerSettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val store = remember { PrayerSettingsStore(context) }
    var settings by remember { mutableStateOf(store.load()) }
    var cityMenu by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val todayTimes = remember(settings.location) {
        val zone = runCatching { ZoneId.of(settings.location.timeZoneId) }.getOrElse { ZoneId.systemDefault() }
        runCatching { PrayerCalculator.calculate(settings.location, LocalDate.now(zone)) }.getOrNull()
    }

    fun persist(next: PrayerSettings) {
        settings = next
        store.save(next)
        PrayerNotificationScheduler.scheduleRollingWindow(context)
    }

    val locationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val granted = result[Manifest.permission.ACCESS_FINE_LOCATION] == true || result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            val loc = bestLastLocation(context)
            if (loc != null) {
                persist(settings.copy(location = PrayerLocation("موقعي الحالي", loc.first, loc.second, TimeZone.getDefault().id)))
                message = "تم استخدام آخر موقع متاح من الجهاز."
            } else message = "لم يجد الجهاز موقعًا محفوظًا بعد. افتح خدمة الموقع وحاول مرة أخرى."
        } else message = "لم يتم منح إذن الموقع. يمكنك اختيار المدينة يدويًا."
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("مواقيت الصلاة والتنبيهات", fontWeight = FontWeight.Bold) },
                navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } },
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Text("الموقع", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Box {
                    OutlinedButton(onClick = { cityMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("المدينة: ${settings.location.name}")
                    }
                    DropdownMenu(expanded = cityMenu, onDismissRequest = { cityMenu = false }) {
                        EgyptCities.all.forEach { city ->
                            DropdownMenuItem(
                                text = { Text(city.name) },
                                onClick = {
                                    cityMenu = false
                                    persist(settings.copy(location = city))
                                },
                            )
                        }
                    }
                }
                TextButton(onClick = {
                    val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    if (fine || coarse) {
                        val loc = bestLastLocation(context)
                        if (loc != null) {
                            persist(settings.copy(location = PrayerLocation("موقعي الحالي", loc.first, loc.second, TimeZone.getDefault().id)))
                            message = "تم استخدام آخر موقع متاح من الجهاز."
                        } else message = "لم يجد الجهاز موقعًا محفوظًا بعد."
                    } else {
                        locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                    }
                }) { Text("استخدام موقع الجهاز") }
                message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
            }

            item {
                Text("مواقيت اليوم", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (todayTimes == null) {
                            Text("تعذر حساب المواقيت لهذا الموقع. اختر مدينة أخرى أو أعد تحديد الموقع.")
                        } else {
                            todayTimes.entries().forEach { (name, epoch) ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(name)
                                    Text(PrayerCalculator.format(epoch, settings.location.timeZoneId), fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
                Text(
                    "الحساب المحلي مضبوط افتراضيًا على طريقة الهيئة المصرية العامة للمساحة. يمكن لاحقًا إضافة تصحيح دقائق يدوي إذا احتجنا مطابقة تقويم مسجد معين.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }

            item {
                Text("وقت التذكير بعد الصلاة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0, 15, 30, 60).forEach { minutes ->
                        FilterChip(
                            selected = settings.delayMinutes == minutes,
                            onClick = { persist(settings.copy(delayMinutes = minutes)) },
                            label = { Text(if (minutes == 0) "مباشرة" else "$minutes د") },
                        )
                    }
                }
            }

            item {
                Text("التنبيهات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                PrayerToggle("الفجر", settings.fajr) { persist(settings.copy(fajr = it)) }
                PrayerToggle("الظهر", settings.dhuhr) { persist(settings.copy(dhuhr = it)) }
                PrayerToggle("العصر", settings.asr) { persist(settings.copy(asr = it)) }
                PrayerToggle("المغرب", settings.maghrib) { persist(settings.copy(maghrib = it)) }
                PrayerToggle("العشاء", settings.isha) { persist(settings.copy(isha = it)) }
                Text(
                    "لو كل أجزاء اليوم اكتملت، العامل المجدول يفحص الحالة ولا يعرض تنبيهات باقي اليوم. وقد يؤخر Android تذكير WorkManager عدة دقائق أحيانًا بسبب إدارة البطارية؛ لا نطلب صلاحية المنبه الدقيق في هذه النسخة.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }

            item { Spacer(Modifier.height(20.dp)) }
        }
    }
}

@Composable
private fun PrayerToggle(name: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("تذكير بعد $name")
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private fun bestLastLocation(context: Context): Pair<Double, Double>? {
    val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val providers = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER)
    return providers.mapNotNull { provider ->
        runCatching { manager.getLastKnownLocation(provider) }.getOrNull()
    }.maxByOrNull { it.time }?.let { it.latitude to it.longitude }
}
