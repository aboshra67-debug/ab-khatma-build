package com.ab.khatma.ui.theme

import android.content.Context
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

enum class KhatmaThemeStyle(val title: String, val subtitle: String) {
    NOOR("نور", "عاجي هادئ مع أخضر ولمسات ذهبية"),
    EMERALD("زمرد", "أخضر زمردي داكن ومريح للعين"),
    NIGHT("ليلي", "كحلي داكن مع بنفسجي هادئ"),
    ROYAL_AB("ملكي AB", "كحلي ملكي وأزرق AB مع ذهبي"),
    RAMADAN("رمضاني", "بنفسجي ليلي وفيروزي مع ذهبي"),
}

data class ThemePreviewPalette(
    val background: Color,
    val surface: Color,
    val primary: Color,
    val accent: Color,
)

fun previewPalette(style: KhatmaThemeStyle): ThemePreviewPalette = when (style) {
    KhatmaThemeStyle.NOOR -> ThemePreviewPalette(
        background = Color(0xFFFFFAF1), surface = Color(0xFFFFFFFF),
        primary = Color(0xFF0A6847), accent = Color(0xFFD3A338),
    )
    KhatmaThemeStyle.EMERALD -> ThemePreviewPalette(
        background = Color(0xFF03291F), surface = Color(0xFF063A2C),
        primary = Color(0xFF8EE3AA), accent = Color(0xFFF0C66A),
    )
    KhatmaThemeStyle.NIGHT -> ThemePreviewPalette(
        background = Color(0xFF071126), surface = Color(0xFF0E1B38),
        primary = Color(0xFFC7A4FF), accent = Color(0xFFF1C75B),
    )
    KhatmaThemeStyle.ROYAL_AB -> ThemePreviewPalette(
        background = Color(0xFF020B1E), surface = Color(0xFF071B3F),
        primary = Color(0xFF2D74FF), accent = Color(0xFFF3C45B),
    )
    KhatmaThemeStyle.RAMADAN -> ThemePreviewPalette(
        background = Color(0xFF10072A), surface = Color(0xFF1A1042),
        primary = Color(0xFF35D6CF), accent = Color(0xFFF2C55E),
    )
}

class ThemePreferences(context: Context) {
    private val prefs = context.getSharedPreferences("khatma_appearance", Context.MODE_PRIVATE)

    fun load(): KhatmaThemeStyle = runCatching {
        KhatmaThemeStyle.valueOf(prefs.getString("theme_style", KhatmaThemeStyle.ROYAL_AB.name)!!)
    }.getOrDefault(KhatmaThemeStyle.ROYAL_AB)

    fun save(style: KhatmaThemeStyle) {
        prefs.edit().putString("theme_style", style.name).apply()
    }
}

private val NoorColors = lightColorScheme(
    primary = Color(0xFF086B4A), onPrimary = Color.White,
    primaryContainer = Color(0xFFDDF3E7), onPrimaryContainer = Color(0xFF073A28),
    secondary = Color(0xFFB88313), onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE8AE), onSecondaryContainer = Color(0xFF4A3600),
    tertiary = Color(0xFF315E9A), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFD9E7FF), onTertiaryContainer = Color(0xFF0B2D55),
    background = Color(0xFFFFFAF1), onBackground = Color(0xFF1C2923),
    surface = Color(0xFFFFFFFF), onSurface = Color(0xFF1C2923),
    surfaceVariant = Color(0xFFF3ECE0), onSurfaceVariant = Color(0xFF4E5C55),
    outline = Color(0xFF7C897F), outlineVariant = Color(0xFFD1D9D3),
    error = Color(0xFFBA1A1A),
)

private val EmeraldColors = darkColorScheme(
    primary = Color(0xFF8EE3AA), onPrimary = Color(0xFF00391F),
    primaryContainer = Color(0xFF0D5A3D), onPrimaryContainer = Color(0xFFD1FFDE),
    secondary = Color(0xFFF0C66A), onSecondary = Color(0xFF3D2E00),
    secondaryContainer = Color(0xFF5A480C), onSecondaryContainer = Color(0xFFFFE6A5),
    tertiary = Color(0xFF7FB8FF), onTertiary = Color(0xFF00325A),
    tertiaryContainer = Color(0xFF144A78), onTertiaryContainer = Color(0xFFD5E6FF),
    background = Color(0xFF03291F), onBackground = Color(0xFFE5F7EC),
    surface = Color(0xFF063A2C), onSurface = Color(0xFFE5F7EC),
    surfaceVariant = Color(0xFF0B4B39), onSurfaceVariant = Color(0xFFC7DBD0),
    outline = Color(0xFF88A397), outlineVariant = Color(0xFF345D4E),
    error = Color(0xFFFFB4AB),
)

private val NightColors = darkColorScheme(
    primary = Color(0xFFC7A4FF), onPrimary = Color(0xFF30105F),
    primaryContainer = Color(0xFF4A2379), onPrimaryContainer = Color(0xFFE9DDFF),
    secondary = Color(0xFFF1C75B), onSecondary = Color(0xFF3B2F00),
    secondaryContainer = Color(0xFF564500), onSecondaryContainer = Color(0xFFFFE58E),
    tertiary = Color(0xFF9FC9FF), onTertiary = Color(0xFF00325A),
    tertiaryContainer = Color(0xFF15486F), onTertiaryContainer = Color(0xFFD1E4FF),
    background = Color(0xFF071126), onBackground = Color(0xFFE5E9F7),
    surface = Color(0xFF0E1B38), onSurface = Color(0xFFE5E9F7),
    surfaceVariant = Color(0xFF172749), onSurfaceVariant = Color(0xFFC7CDDF),
    outline = Color(0xFF8D95AA), outlineVariant = Color(0xFF394661),
    error = Color(0xFFFFB4AB),
)

private val RoyalAbColors = darkColorScheme(
    primary = Color(0xFF3D7FFF), onPrimary = Color.White,
    primaryContainer = Color(0xFF0B2C67), onPrimaryContainer = Color(0xFFE2ECFF),
    secondary = Color(0xFFF3C45B), onSecondary = Color(0xFF342500),
    secondaryContainer = Color(0xFF5B4300), onSecondaryContainer = Color(0xFFFFE3A1),
    tertiary = Color(0xFF59C7FF), onTertiary = Color(0xFF002E49),
    tertiaryContainer = Color(0xFF004667), onTertiaryContainer = Color(0xFFC6E9FF),
    background = Color(0xFF020B1E), onBackground = Color(0xFFF2F5FF),
    surface = Color(0xFF071B3F), onSurface = Color(0xFFF2F5FF),
    surfaceVariant = Color(0xFF0D2856), onSurfaceVariant = Color(0xFFC8D5EF),
    outline = Color(0xFF8498BF), outlineVariant = Color(0xFF28466F),
    error = Color(0xFFFFB4AB),
)

private val RamadanColors = darkColorScheme(
    primary = Color(0xFF35D6CF), onPrimary = Color(0xFF003735),
    primaryContainer = Color(0xFF075F5B), onPrimaryContainer = Color(0xFFB5F4F0),
    secondary = Color(0xFFF2C55E), onSecondary = Color(0xFF3A2E00),
    secondaryContainer = Color(0xFF594600), onSecondaryContainer = Color(0xFFFFE59A),
    tertiary = Color(0xFFB89BFF), onTertiary = Color(0xFF2B0E61),
    tertiaryContainer = Color(0xFF48297B), onTertiaryContainer = Color(0xFFE8DDFF),
    background = Color(0xFF10072A), onBackground = Color(0xFFF2ECFF),
    surface = Color(0xFF1A1042), onSurface = Color(0xFFF2ECFF),
    surfaceVariant = Color(0xFF2A1B58), onSurfaceVariant = Color(0xFFD2C8E9),
    outline = Color(0xFF9C8EB6), outlineVariant = Color(0xFF4C3B70),
    error = Color(0xFFFFB4AB),
)

private val KhatmaShapes = Shapes(
    extraSmall = RoundedCornerShape(10),
    small = RoundedCornerShape(14),
    medium = RoundedCornerShape(20),
    large = RoundedCornerShape(28),
    extraLarge = RoundedCornerShape(34),
)

private val KhatmaTypography = Typography(
    headlineMedium = TextStyle(fontSize = 28.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold),
    headlineSmall = TextStyle(fontSize = 24.sp, lineHeight = 32.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 20.sp, lineHeight = 28.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 17.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 25.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 22.sp),
    labelLarge = TextStyle(fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
)

@Composable
fun KhatmaTheme(style: KhatmaThemeStyle, content: @Composable () -> Unit) {
    val colors = when (style) {
        KhatmaThemeStyle.NOOR -> NoorColors
        KhatmaThemeStyle.EMERALD -> EmeraldColors
        KhatmaThemeStyle.NIGHT -> NightColors
        KhatmaThemeStyle.ROYAL_AB -> RoyalAbColors
        KhatmaThemeStyle.RAMADAN -> RamadanColors
    }
    MaterialTheme(
        colorScheme = colors,
        typography = KhatmaTypography,
        shapes = KhatmaShapes,
        content = content,
    )
}
