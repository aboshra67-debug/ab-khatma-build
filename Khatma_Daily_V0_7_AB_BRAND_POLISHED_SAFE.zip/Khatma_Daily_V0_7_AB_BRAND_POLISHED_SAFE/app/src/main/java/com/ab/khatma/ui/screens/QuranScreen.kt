package com.ab.khatma.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ab.khatma.quran.QuranPrefsStore
import com.ab.khatma.quran.QuranRepository

private enum class QuranMode { MADINA_PAGES, FLEX_TEXT }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuranScreen(initialJuz: Int?, onBack: () -> Unit) {
    val context = LocalContext.current
    val repo = remember { QuranRepository(context) }
    val prefs = remember { QuranPrefsStore(context) }
    var juz by remember { mutableIntStateOf((initialJuz ?: prefs.lastJuz()).coerceIn(1, 30)) }
    var mode by remember {
        mutableStateOf(runCatching { QuranMode.valueOf(prefs.mode()) }.getOrDefault(QuranMode.FLEX_TEXT))
    }
    var fontSize by remember { mutableFloatStateOf(prefs.fontSize()) }
    var bookmark by remember { mutableStateOf(prefs.bookmark()) }
    val ayahs = remember(juz) { repo.loadJuz(juz) }

    LaunchedEffect(juz) { prefs.saveLastJuz(juz) }
    LaunchedEffect(mode) { prefs.saveMode(mode.name) }
    LaunchedEffect(fontSize) { prefs.saveFontSize(fontSize) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("المصحف — الجزء $juz", fontWeight = FontWeight.Bold) },
                navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } },
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp)) {
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = mode == QuranMode.FLEX_TEXT,
                    onClick = { mode = QuranMode.FLEX_TEXT },
                    shape = SegmentedButtonDefaults.itemShape(0, 2),
                ) { Text("النص المرن") }
                SegmentedButton(
                    selected = mode == QuranMode.MADINA_PAGES,
                    onClick = { mode = QuranMode.MADINA_PAGES },
                    shape = SegmentedButtonDefaults.itemShape(1, 2),
                ) { Text("صفحات المدينة") }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { if (juz > 1) juz-- }, enabled = juz > 1) { Text("الجزء السابق") }
                OutlinedButton(onClick = { if (juz < 30) juz++ }, enabled = juz < 30) { Text("الجزء التالي") }
            }
            bookmark?.let { (surah, ayah) ->
                Text(
                    "العلامة المرجعية: سورة $surah — آية $ayah",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
            Spacer(Modifier.height(8.dp))

            if (!repo.isBundled()) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("قارئ المصحف جاهز هيكليًا", fontWeight = FontWeight.Bold)
                        Text("لن أضع نصًا قرآنيًا غير متحقق. ملف النص العثماني الموثق سيُدمج حرفيًا في المرحلة التالية مع بيانات الجزء والصفحة، وبعدها يعمل القارئ بالكامل بدون إنترنت.")
                        Spacer(Modifier.height(8.dp))
                        Text("المصدر المعتمد للتجهيز: Tanzil Uthmani — مع نسبة المصدر وعدم تغيير النص.", style = MaterialTheme.typography.bodySmall)
                    }
                }
                return@Column
            }

            if (mode == QuranMode.FLEX_TEXT) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { fontSize = (fontSize - 2).coerceAtLeast(20f) }) { Text("تصغير") }
                    TextButton(onClick = { fontSize = (fontSize + 2).coerceAtMost(46f) }) { Text("تكبير") }
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(ayahs, key = { "${it.surah}:${it.ayah}" }) { aya ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.Top,
                        ) {
                            Text(
                                text = "${aya.text}  ﴿${aya.ayah}﴾",
                                fontSize = fontSize.sp,
                                lineHeight = (fontSize * 1.8f).sp,
                                textAlign = TextAlign.Justify,
                                modifier = Modifier.weight(1f).padding(vertical = 6.dp),
                            )
                            IconButton(onClick = {
                                prefs.saveBookmark(aya.surah, aya.ayah)
                                bookmark = aya.surah to aya.ayah
                            }) {
                                val selected = bookmark == (aya.surah to aya.ayah)
                                Icon(
                                    if (selected) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                                    contentDescription = "حفظ علامة مرجعية",
                                )
                            }
                        }
                    }
                }
            } else {
                val pages = ayahs.groupBy { it.page }.toSortedMap()
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    pages.forEach { (page, pageAyahs) ->
                        item(key = "page_$page") {
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(18.dp)) {
                                    Text("صفحة $page", fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(10.dp))
                                    Text(
                                        pageAyahs.joinToString("  ") { "${it.text} ﴿${it.ayah}﴾" },
                                        fontSize = 27.sp,
                                        lineHeight = 50.sp,
                                        textAlign = TextAlign.Justify,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
