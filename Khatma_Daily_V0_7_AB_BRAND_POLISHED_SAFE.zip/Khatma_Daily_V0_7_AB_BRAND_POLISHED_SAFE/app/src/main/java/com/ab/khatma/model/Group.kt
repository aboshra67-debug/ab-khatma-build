package com.ab.khatma.model

data class TodayGroup(
    val groupId: Long,
    val groupName: String,
    val role: String,
    val membershipStatus: String,
    val assignmentId: Long?,
    val khatmaNumber: Int?,
    val juzNumber: Int?,
    val completed: Boolean,
    val completedCount: Int,
    val totalCount: Int,
)

data class LeaderMember(
    val membershipId: Long,
    val userId: Long,
    val name: String,
    val role: String,
    val khatmaNumber: Int?,
    val juzNumber: Int?,
    val completed: Boolean,
)

data class LeaderStatus(
    val groupId: Long,
    val groupName: String,
    val inviteCode: String,
    val completedCount: Int,
    val totalCount: Int,
    val pendingCount: Int,
    val members: List<LeaderMember>,
)

data class GroupCreated(
    val id: Long,
    val name: String,
    val inviteCode: String,
)

data class PendingMember(
    val membershipId: Long,
    val userId: Long,
    val name: String,
)
