package com.ab.khatma.offline

import android.content.Context
import com.ab.khatma.model.TodayGroup
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

class OfflineStore(context: Context) {
    private val prefs = context.getSharedPreferences("khatma_offline", Context.MODE_PRIVATE)

    fun saveGroups(groups: List<TodayGroup>) {
        val pendingIds = pendingCompletions().map { it.assignmentId }.toSet()
        val merged = groups.map { group ->
            if (group.assignmentId != null && group.assignmentId in pendingIds && !group.completed) {
                group.copy(
                    completed = true,
                    completedCount = (group.completedCount + 1).coerceAtMost(group.totalCount.coerceAtLeast(1)),
                )
            } else group
        }
        val arr = JSONArray()
        merged.forEach { g ->
            arr.put(
                JSONObject()
                    .put("group_id", g.groupId)
                    .put("group_name", g.groupName)
                    .put("role", g.role)
                    .put("membership_status", g.membershipStatus)
                    .put("assignment_id", g.assignmentId)
                    .put("khatma_number", g.khatmaNumber)
                    .put("juz_number", g.juzNumber)
                    .put("completed", g.completed)
                    .put("completed_count", g.completedCount)
                    .put("total_count", g.totalCount)
            )
        }
        prefs.edit().putString("today_groups", arr.toString()).putString("cache_date", LocalDate.now().toString()).apply()
    }

    fun loadGroups(): List<TodayGroup> {
        if (prefs.getString("cache_date", "") != LocalDate.now().toString()) return emptyList()
        val text = prefs.getString("today_groups", "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(text)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(
                        TodayGroup(
                            groupId = o.getLong("group_id"),
                            groupName = o.getString("group_name"),
                            role = o.getString("role"),
                            membershipStatus = o.getString("membership_status"),
                            assignmentId = o.optLongOrNull("assignment_id"),
                            khatmaNumber = o.optIntOrNull("khatma_number"),
                            juzNumber = o.optIntOrNull("juz_number"),
                            completed = o.optBoolean("completed", false),
                            completedCount = o.optInt("completed_count", 0),
                            totalCount = o.optInt("total_count", 0),
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun markCompletedLocally(assignmentId: Long): List<TodayGroup> {
        val updated = loadGroups().map { group ->
            if (group.assignmentId == assignmentId && !group.completed) {
                group.copy(
                    completed = true,
                    completedCount = (group.completedCount + 1).coerceAtMost(group.totalCount.coerceAtLeast(1))
                )
            } else group
        }
        saveGroups(updated)
        return updated
    }

    fun queueCompletion(assignmentId: Long, userId: Long) {
        val pending = pendingCompletions().toMutableList()
        if (pending.none { it.assignmentId == assignmentId }) {
            pending += PendingCompletion(assignmentId, userId)
            savePending(pending)
        }
    }

    fun pendingCompletions(): List<PendingCompletion> {
        val arr = JSONArray(prefs.getString("pending_completions", "[]") ?: "[]")
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(PendingCompletion(o.getLong("assignment_id"), o.getLong("user_id")))
            }
        }
    }

    fun removePending(assignmentId: Long) {
        savePending(pendingCompletions().filterNot { it.assignmentId == assignmentId })
    }

    fun incompleteGroups(): List<TodayGroup> = loadGroups().filter {
        it.membershipStatus == "active" && it.assignmentId != null && !it.completed
    }

    private fun savePending(items: List<PendingCompletion>) {
        val arr = JSONArray()
        items.forEach { arr.put(JSONObject().put("assignment_id", it.assignmentId).put("user_id", it.userId)) }
        prefs.edit().putString("pending_completions", arr.toString()).apply()
    }

    private fun JSONObject.optLongOrNull(key: String): Long? = if (!has(key) || isNull(key)) null else getLong(key)
    private fun JSONObject.optIntOrNull(key: String): Int? = if (!has(key) || isNull(key)) null else getInt(key)
}

data class PendingCompletion(val assignmentId: Long, val userId: Long)
