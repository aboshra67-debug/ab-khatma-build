package com.ab.khatma

import android.app.Application
import com.ab.khatma.prayer.PrayerNotificationScheduler

class KhatmaApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        PrayerNotificationScheduler.ensureChannel(this)
        PrayerNotificationScheduler.scheduleRollingWindow(this)
        PrayerNotificationScheduler.ensurePeriodicRefresh(this)
    }
}
