package com.ab.khatma.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.ab.khatma.AppViewModel
import com.ab.khatma.R
import com.ab.khatma.ui.theme.KhatmaThemeStyle
import com.ab.khatma.ui.theme.previewPalette
import kotlinx.coroutines.delay

private sealed interface Screen {
    data object Welcome : Screen
    data object Home : Screen
    data object CreateGroup : Screen
    data object JoinGroup : Screen
    data object PrayerSettings : Screen
    data object Appearance : Screen
    data class Quran(val juz: Int?) : Screen
    data class Leader(val groupId: Long) : Screen
}

@Composable
fun AppRoot(vm: AppViewModel, themeStyle: KhatmaThemeStyle, onThemeStyleChange: (KhatmaThemeStyle) -> Unit) {
    var screen by remember { mutableStateOf<Screen>(if (vm.userId > 0) Screen.Home else Screen.Welcome) }

    vm.error?.let { message ->
        AlertDialog(
            onDismissRequest = vm::clearError,
            confirmButton = { TextButton(onClick = vm::clearError) { Text("حسنًا") } },
            title = { Text("تنبيه") },
            text = { Text(message) },
        )
    }

    vm.lastCreatedGroup?.let { group ->
        AlertDialog(
            onDismissRequest = vm::clearCreatedGroup,
            confirmButton = { TextButton(onClick = vm::clearCreatedGroup) { Text("تم") } },
            title = { Text("تم إنشاء المجموعة") },
            text = { Text("كود الدعوة: ${group.inviteCode}\nأرسله للأعضاء للانضمام للمجموعة.") },
        )
    }

    when (val current = screen) {
        Screen.Welcome -> WelcomeScreen(vm.loading) { name -> vm.register(name) { screen = Screen.Home } }
        Screen.Home -> HomeScreen(
            userName = vm.userName,
            groups = vm.groups,
            loading = vm.loading,
            isOffline = vm.isOffline,
            onRefresh = vm::refreshToday,
            onCreateGroup = { screen = Screen.CreateGroup },
            onJoinGroup = { screen = Screen.JoinGroup },
            onComplete = vm::complete,
            onLeaderOpen = { id -> vm.loadLeaderStatus(id); screen = Screen.Leader(id) },
            onOpenQuran = { juz -> screen = Screen.Quran(juz) },
            onOpenPrayerSettings = { screen = Screen.PrayerSettings },
            onOpenAppearance = { screen = Screen.Appearance },
        )
        Screen.CreateGroup -> CreateGroupScreen(vm.loading, onBack = { screen = Screen.Home }) { name, participates ->
            vm.createGroup(name, participates) { screen = Screen.Home }
        }
        Screen.JoinGroup -> JoinGroupScreen(vm.loading, onBack = { screen = Screen.Home }) { code ->
            vm.joinGroup(code) { screen = Screen.Home }
        }
        Screen.PrayerSettings -> PrayerSettingsScreen(onBack = { screen = Screen.Home })
        Screen.Appearance -> AppearanceScreen(themeStyle, onThemeStyleChange, onBack = { screen = Screen.Home })
        is Screen.Quran -> QuranScreen(initialJuz = current.juz, onBack = { screen = Screen.Home })
        is Screen.Leader -> {
            LaunchedEffect(current.groupId) {
                while (true) {
                    delay(5_000)
                    vm.loadLeaderStatus(current.groupId)
                }
            }
            LeaderGroupScreen(
                status = vm.leaderStatus,
                pending = vm.pendingMembers,
                loading = vm.loading,
                onBack = { screen = Screen.Home },
                onRefresh = { vm.loadLeaderStatus(current.groupId) },
                onApprove = { membershipId, approve -> vm.approveMember(current.groupId, membershipId, approve) },
                onChangeJuz = { membershipId, juz -> vm.changeMemberJuz(current.groupId, membershipId, juz) },
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WelcomeScreen(loading: Boolean, onRegister: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    Scaffold(topBar = { TopAppBar(title = { Text("ختمة", fontWeight = FontWeight.Bold) }) }) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(
                painter = painterResource(R.drawable.ab_khatma_logo_full),
                contentDescription = "شعار AB ختمة",
                modifier = Modifier.size(230.dp),
                contentScale = ContentScale.Fit,
            )
            Spacer(Modifier.height(6.dp))
            Text("أهلًا بك", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("اكتب اسمك للبدء. التحقق برقم الهاتف سيضاف في مرحلة الأمان.")
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("الاسم") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            Button(onClick = { onRegister(name) }, enabled = name.trim().length >= 2 && !loading, modifier = Modifier.fillMaxWidth()) {
                Text(if (loading) "جاري التسجيل..." else "ابدأ")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CreateGroupScreen(loading: Boolean, onBack: () -> Unit, onCreate: (String, Boolean) -> Unit) {
    var name by remember { mutableStateOf("") }
    var participates by remember { mutableStateOf(false) }
    Scaffold(topBar = { TopAppBar(title = { Text("إنشاء مجموعة") }, navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } }) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("اسم المجموعة") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            Text("الانضمام يحتاج موافقة القائد افتراضيًا.")
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("القائد يشارك كقارئ ويأخذ جزءًا")
                Switch(checked = participates, onCheckedChange = { participates = it })
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = { onCreate(name, participates) }, enabled = name.trim().length >= 2 && !loading, modifier = Modifier.fillMaxWidth()) {
                Text("إنشاء المجموعة")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun JoinGroupScreen(loading: Boolean, onBack: () -> Unit, onJoin: (String) -> Unit) {
    var code by remember { mutableStateOf("") }
    Scaffold(topBar = { TopAppBar(title = { Text("الانضمام لمجموعة") }, navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } }) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            OutlinedTextField(
                value = code,
                onValueChange = { code = it.uppercase() },
                label = { Text("كود المجموعة") },
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = { onJoin(code) }, enabled = code.trim().length >= 4 && !loading, modifier = Modifier.fillMaxWidth()) {
                Text("إرسال طلب الانضمام")
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppearanceScreen(
    selected: KhatmaThemeStyle,
    onSelect: (KhatmaThemeStyle) -> Unit,
    onBack: () -> Unit,
) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("المظهر والثيمات", fontWeight = FontWeight.Bold) },
                navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                ),
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Image(
                    painter = painterResource(R.drawable.ab_khatma_mark),
                    contentDescription = "AB ختمة",
                    modifier = Modifier.size(72.dp),
                    contentScale = ContentScale.Fit,
                )
                Column {
                    Text("الثيمات", style = MaterialTheme.typography.headlineSmall)
                    Text("هوية AB ختمة — اختر الشكل الأقرب لك", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Text(
                "التغيير يظهر فورًا ويُحفظ تلقائيًا على الجهاز.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            KhatmaThemeStyle.entries.forEach { style ->
                val palette = previewPalette(style)
                val isSelected = selected == style
                Card(
                    onClick = { onSelect(style) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(
                        if (isSelected) 2.dp else 1.dp,
                        if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 0.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        Box(
                            modifier = Modifier
                                .size(68.dp)
                                .background(palette.background, MaterialTheme.shapes.medium)
                                .padding(9.dp),
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(palette.surface, MaterialTheme.shapes.small)
                                    .padding(8.dp),
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(20.dp)
                                        .align(Alignment.TopStart)
                                        .background(palette.primary, CircleShape),
                                )
                                Box(
                                    modifier = Modifier
                                        .size(14.dp)
                                        .align(Alignment.BottomEnd)
                                        .background(palette.accent, CircleShape),
                                )
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                when (style) {
                                    KhatmaThemeStyle.NOOR -> "☀️  ${style.title}"
                                    KhatmaThemeStyle.EMERALD -> "💎  ${style.title}"
                                    KhatmaThemeStyle.NIGHT -> "🌙  ${style.title}"
                                    KhatmaThemeStyle.ROYAL_AB -> "👑  ${style.title}"
                                    KhatmaThemeStyle.RAMADAN -> "🏮  ${style.title}"
                                },
                                style = MaterialTheme.typography.titleLarge,
                            )
                            Spacer(Modifier.height(3.dp))
                            Text(
                                style.subtitle,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }

                        RadioButton(selected = isSelected, onClick = { onSelect(style) })
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.28f)),
            ) {
                Text(
                    "ملاحظة: زمرد، ليلي، ملكي AB ورمضاني بخلفيات داكنة مناسبة للقراءة المسائية.",
                    modifier = Modifier.padding(14.dp),
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                )
            }
        }
    }
}
