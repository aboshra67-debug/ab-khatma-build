package com.ab.khatma

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ab.khatma.model.GroupCreated
import com.ab.khatma.model.LeaderStatus
import com.ab.khatma.model.PendingMember
import com.ab.khatma.model.TodayGroup
import com.ab.khatma.network.ApiClient
import com.ab.khatma.offline.OfflineStore
import com.ab.khatma.offline.SyncWorker
import com.ab.khatma.prayer.PrayerNotificationScheduler
import com.ab.khatma.storage.SessionStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val session = SessionStore(application)
    private val offline = OfflineStore(application)

    var userId by mutableStateOf(session.userId())
        private set
    var userName by mutableStateOf(session.userName())
        private set
    var groups by mutableStateOf(offline.loadGroups())
        private set
    var loading by mutableStateOf(false)
        private set
    var isOffline by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var lastCreatedGroup by mutableStateOf<GroupCreated?>(null)
        private set
    var leaderStatus by mutableStateOf<LeaderStatus?>(null)
        private set
    var pendingMembers by mutableStateOf<List<PendingMember>>(emptyList())
        private set

    init {
        PrayerNotificationScheduler.scheduleRollingWindow(application)
        if (userId > 0) refreshToday()
    }

    fun register(name: String, onDone: () -> Unit) = runTask {
        val result = withContext(Dispatchers.IO) { ApiClient.createUser(name.trim()) }
        userId = result.first
        userName = result.second
        session.saveUser(userId, userName)
        groups = emptyList()
        offline.saveGroups(emptyList())
        isOffline = false
        onDone()
    }

    fun refreshToday() {
        if (userId <= 0) return
        viewModelScope.launch {
            val showLoading = groups.isEmpty()
            if (showLoading) loading = true
            try {
                val fresh = withContext(Dispatchers.IO) { ApiClient.today(userId) }
                groups = fresh
                offline.saveGroups(fresh)
                isOffline = false
                SyncWorker.enqueue(getApplication())
            } catch (e: Exception) {
                isOffline = true
                if (groups.isEmpty()) error = "لا يوجد اتصال بالإنترنت ولا توجد بيانات محفوظة بعد."
            } finally {
                if (showLoading) loading = false
            }
        }
    }

    fun createGroup(name: String, leaderParticipates: Boolean, onDone: (GroupCreated) -> Unit) = runTask {
        val created = withContext(Dispatchers.IO) { ApiClient.createGroup(name.trim(), userId, leaderParticipates) }
        lastCreatedGroup = created
        val fresh = withContext(Dispatchers.IO) { ApiClient.today(userId) }
        groups = fresh
        offline.saveGroups(fresh)
        isOffline = false
        onDone(created)
    }

    fun joinGroup(code: String, onDone: (String) -> Unit) = runTask {
        val status = withContext(Dispatchers.IO) { ApiClient.joinGroup(code.trim(), userId) }
        val fresh = withContext(Dispatchers.IO) { ApiClient.today(userId) }
        groups = fresh
        offline.saveGroups(fresh)
        isOffline = false
        onDone(status)
    }

    fun complete(group: TodayGroup) {
        val assignmentId = group.assignmentId ?: return
        if (group.completed) return
        groups = offline.markCompletedLocally(assignmentId)
        offline.queueCompletion(assignmentId, userId)
        SyncWorker.enqueue(getApplication())
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { ApiClient.completeAssignment(assignmentId, userId) }
                .onSuccess {
                    offline.removePending(assignmentId)
                    runCatching { ApiClient.today(userId) }.onSuccess { fresh ->
                        offline.saveGroups(fresh)
                        withContext(Dispatchers.Main) {
                            groups = fresh
                            isOffline = false
                        }
                    }
                }
                .onFailure { withContext(Dispatchers.Main) { isOffline = true } }
        }
    }

    fun loadLeaderStatus(groupId: Long) = runTask(showLoading = leaderStatus == null || leaderStatus?.groupId != groupId) {
        leaderStatus = withContext(Dispatchers.IO) { ApiClient.leaderStatus(groupId, userId) }
        pendingMembers = withContext(Dispatchers.IO) { ApiClient.pendingMembers(groupId, userId) }
        isOffline = false
    }

    fun changeMemberJuz(groupId: Long, membershipId: Long, juz: Int) = runTask(showLoading = false) {
        withContext(Dispatchers.IO) { ApiClient.changeMemberJuz(groupId, membershipId, userId, juz) }
        leaderStatus = withContext(Dispatchers.IO) { ApiClient.leaderStatus(groupId, userId) }
        val fresh = withContext(Dispatchers.IO) { ApiClient.today(userId) }
        groups = fresh
        offline.saveGroups(fresh)
    }

    fun approveMember(groupId: Long, membershipId: Long, approve: Boolean) = runTask(showLoading = false) {
        withContext(Dispatchers.IO) { ApiClient.approveMember(groupId, membershipId, userId, approve) }
        leaderStatus = withContext(Dispatchers.IO) { ApiClient.leaderStatus(groupId, userId) }
        pendingMembers = withContext(Dispatchers.IO) { ApiClient.pendingMembers(groupId, userId) }
        val fresh = withContext(Dispatchers.IO) { ApiClient.today(userId) }
        groups = fresh
        offline.saveGroups(fresh)
    }

    fun clearCreatedGroup() { lastCreatedGroup = null }
    fun clearError() { error = null }

    private fun runTask(showLoading: Boolean = true, block: suspend () -> Unit) {
        viewModelScope.launch {
            if (showLoading) loading = true
            error = null
            try {
                block()
            } catch (e: Exception) {
                isOffline = true
                error = e.message ?: "حدث خطأ غير متوقع"
            } finally {
                if (showLoading) loading = false
            }
        }
    }
}
