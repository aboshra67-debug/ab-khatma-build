package com.ab.khatma.prayer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.work.Data
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.time.LocalDate
import java.time.ZoneId
import java.util.concurrent.TimeUnit

object PrayerNotificationScheduler {
    const val CHANNEL_ID = "khatma_prayer_reminders"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "تذكير قراءة القرآن بعد الصلاة", NotificationManager.IMPORTANCE_DEFAULT)
            channel.description = "تنبيه بالجزء غير المكتمل بعد الصلوات"
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    fun scheduleRollingWindow(context: Context) {
        val settings = PrayerSettingsStore(context).load()
        val now = System.currentTimeMillis()
        for (plusDays in 0L..1L) {
            val zone = runCatching { ZoneId.of(settings.location.timeZoneId) }.getOrElse { ZoneId.systemDefault() }
            val date = LocalDate.now(zone).plusDays(plusDays)
            val times = runCatching { PrayerCalculator.calculate(settings.location, date) }.getOrNull() ?: continue
            val enabled = mapOf(
                "الفجر" to settings.fajr,
                "الظهر" to settings.dhuhr,
                "العصر" to settings.asr,
                "المغرب" to settings.maghrib,
                "العشاء" to settings.isha,
            )
            times.entries().forEach { (name, time) ->
                val key = "prayer_${date}_${name}"
                val workManager = WorkManager.getInstance(context)
                if (enabled[name] != true) {
                    workManager.cancelUniqueWork(key)
                    return@forEach
                }
                val target = time + settings.delayMinutes * 60_000L
                if (target <= now) return@forEach
                val input = Data.Builder().putString("prayer_name", name).build()
                val work = OneTimeWorkRequestBuilder<PrayerReminderWorker>()
                    .setInputData(input)
                    .setInitialDelay(target - now, TimeUnit.MILLISECONDS)
                    .build()
                workManager.enqueueUniqueWork(key, ExistingWorkPolicy.REPLACE, work)
            }
        }

    }

    fun ensurePeriodicRefresh(context: Context) {
        val refresh = PeriodicWorkRequestBuilder<PrayerScheduleRefreshWorker>(12, TimeUnit.HOURS).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "prayer_schedule_refresh",
            ExistingPeriodicWorkPolicy.UPDATE,
            refresh,
        )
    }
}
