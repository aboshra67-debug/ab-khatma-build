package com.ab.khatma.quran

import android.content.Context

class QuranPrefsStore(context: Context) {
    private val prefs = context.getSharedPreferences("quran_reader_prefs", Context.MODE_PRIVATE)

    fun lastJuz(): Int = prefs.getInt("last_juz", 1).coerceIn(1, 30)
    fun saveLastJuz(juz: Int) = prefs.edit().putInt("last_juz", juz.coerceIn(1, 30)).apply()

    fun mode(): String = prefs.getString("mode", "FLEX_TEXT") ?: "FLEX_TEXT"
    fun saveMode(mode: String) = prefs.edit().putString("mode", mode).apply()

    fun fontSize(): Float = prefs.getFloat("font_size", 30f).coerceIn(20f, 46f)
    fun saveFontSize(size: Float) = prefs.edit().putFloat("font_size", size.coerceIn(20f, 46f)).apply()

    fun bookmark(): Pair<Int, Int>? {
        val surah = prefs.getInt("bookmark_surah", 0)
        val ayah = prefs.getInt("bookmark_ayah", 0)
        return if (surah > 0 && ayah > 0) surah to ayah else null
    }

    fun saveBookmark(surah: Int, ayah: Int) = prefs.edit()
        .putInt("bookmark_surah", surah)
        .putInt("bookmark_ayah", ayah)
        .apply()
}
