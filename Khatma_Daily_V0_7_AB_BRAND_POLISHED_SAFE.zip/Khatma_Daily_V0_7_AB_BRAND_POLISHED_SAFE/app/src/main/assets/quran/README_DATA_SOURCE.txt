QURAN DATA SLOT — V0.3

The reader is wired to load: quran/quran-uthmani.json
Expected JSON fields per ayah: surah, ayah, text, juz, page.

Do not insert unverified Quran text.
Planned source: Tanzil Quran Text (Uthmani), verbatim, with its required attribution and update link.
Tanzil terms require that the Quran text is not changed and that source attribution is shown in the application.
No Quran text is bundled in V0.3 until the verified source file is imported verbatim and validated.
