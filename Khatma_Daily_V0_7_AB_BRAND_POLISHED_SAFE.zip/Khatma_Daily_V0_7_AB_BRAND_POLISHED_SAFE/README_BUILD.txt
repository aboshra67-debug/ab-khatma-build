AB Khatma V0.7.0 — AB_BRAND_POLISHED_SAFE
=========================================

Purpose
-------
Safe visual branding patch based on V0.6. No working feature was removed.

App identity
------------
applicationId: com.ab.khatma.app
versionCode: 7
versionName: 0.7.0
minSdk: 26
targetSdk / compileSdk: 36
JDK: 17
Gradle: 9.5.0

AB brand
--------
- Approved AB + crescent + star + Qur'an logo embedded in the app.
- AB stays to the side of the crescent composition, not centered over the Qur'an.
- Real launcher icons for mdpi/hdpi/xhdpi/xxhdpi/xxxhdpi.
- Adaptive icon for Android 8+.
- Lightweight branded splash screen.
- Brand mark appears in the Home header, Hero card, Welcome and Appearance screens.

Themes
------
1) Noor: ivory + green + gold.
2) Emerald: dark emerald + gold.
3) Night: dark navy + purple + gold.
4) Royal AB: royal navy + AB blue + gold. Default for new installs.
5) Ramadan: deep purple + turquoise + gold.
Theme selection is saved locally.

Server
------
Production test server:
https://balanced-creativity-production-f316.up.railway.app
Health endpoint: /health

Build
-----
The included build-apk.yml applies the Android 36 compatibility patch, builds Debug, and verifies the APK signature with apksigner.
Expected artifact:
AB_Khatma_V0.7_AB_BRAND_SERVER_CONNECTED_APK

Verification
------------
python3 tools/verify_project.py
Expected:
VERIFY PASS / AB Khatma V0.7.0 (7) / AB_BRAND_POLISHED_SAFE

Preserved functionality
-----------------------
- leader/member groups and daily juz assignment
- offline completion queue and synchronization
- PostgreSQL/FastAPI integration
- prayer reminder framework
- Quran reader framework/preferences
- Railway HTTPS API configuration
