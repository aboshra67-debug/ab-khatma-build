# AB Khatma V0.8

- Restored production application ID to `com.ab.khatma`, matching the known-working V0.4 APK.
- Debug builds use `com.ab.khatma.preview` so the visual test installs beside V0.4 and cannot overwrite it.
- Railway production URL is now the source default (still overrideable through `KHATMA_API_BASE_URL`).
- Android 36 compatible Compose/core/activity versions are pinned directly in source.
- Debug manifest conflict is fixed in source with `tools:replace`.
- AB logo, splash, launcher icon, and five themes are retained.
- No server/group/offline/prayer/Quran business logic was removed.
