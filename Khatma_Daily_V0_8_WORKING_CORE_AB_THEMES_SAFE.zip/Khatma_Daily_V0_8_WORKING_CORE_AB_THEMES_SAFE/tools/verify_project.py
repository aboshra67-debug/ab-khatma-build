from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
required = [
    ROOT / 'settings.gradle.kts',
    ROOT / 'build.gradle.kts',
    ROOT / 'gradle.properties',
    ROOT / 'app' / 'build.gradle.kts',
    ROOT / 'app' / 'src' / 'main' / 'AndroidManifest.xml',
    ROOT / 'app' / 'src' / 'debug' / 'AndroidManifest.xml',
    ROOT / 'app' / 'src' / 'main' / 'java' / 'com' / 'ab' / 'khatma' / 'MainActivity.kt',
    ROOT / 'app' / 'src' / 'main' / 'java' / 'com' / 'ab' / 'khatma' / 'ui' / 'theme' / 'KhatmaTheme.kt',
    ROOT / 'server' / 'app' / 'main.py',
]
missing = [str(p.relative_to(ROOT)) for p in required if not p.exists()]
if missing:
    print('VERIFY FAIL - missing files:')
    for x in missing: print(' -', x)
    sys.exit(1)

app_gradle = (ROOT / 'app' / 'build.gradle.kts').read_text(encoding='utf-8')
checks = {
    'production applicationId matches working V0.4': 'applicationId = "com.ab.khatma"' in app_gradle,
    'preview installs beside production': 'applicationIdSuffix = ".preview"' in app_gradle,
    'versionCode 8': 'versionCode = 8' in app_gradle,
    'versionName 0.8.0': 'versionName = "0.8.0"' in app_gradle,
    'compileSdk 36': 'compileSdk = 36' in app_gradle,
    'targetSdk 36': 'targetSdk = 36' in app_gradle,
    'live Railway default': 'https://balanced-creativity-production-f316.up.railway.app' in app_gradle,
    'Compose Android 36 BOM pinned': 'compose-bom:2026.06.00' in app_gradle,
}
failed = [k for k,v in checks.items() if not v]
if failed:
    print('VERIFY FAIL - checks:')
    for x in failed: print(' -', x)
    sys.exit(1)

manifest=(ROOT/'app'/'src'/'main'/'AndroidManifest.xml').read_text(encoding='utf-8')
if 'android:usesCleartextTraffic="false"' not in manifest:
    print('VERIFY FAIL - production cleartext traffic must remain disabled')
    sys.exit(1)

debug_manifest=(ROOT/'app'/'src'/'debug'/'AndroidManifest.xml').read_text(encoding='utf-8')
if 'tools:replace="android:usesCleartextTraffic"' not in debug_manifest:
    print('VERIFY FAIL - debug manifest override missing')
    sys.exit(1)

logo = ROOT / 'app' / 'src' / 'main' / 'res' / 'drawable-nodpi' / 'ab_khatma_logo_full.png'
if not logo.exists() or logo.stat().st_size < 50000:
    print('VERIFY FAIL - AB brand logo missing or too small')
    sys.exit(1)

theme=(ROOT/'app'/'src'/'main'/'java'/'com'/'ab'/'khatma'/'ui'/'theme'/'KhatmaTheme.kt').read_text(encoding='utf-8')
for token in ['NOOR', 'EMERALD', 'NIGHT', 'ROYAL_AB', 'RAMADAN']:
    if token not in theme:
        print('VERIFY FAIL - missing theme', token)
        sys.exit(1)

print('VERIFY PASS / AB Khatma V0.8.0 / working V0.4 core identity + AB brand + 5 themes')
