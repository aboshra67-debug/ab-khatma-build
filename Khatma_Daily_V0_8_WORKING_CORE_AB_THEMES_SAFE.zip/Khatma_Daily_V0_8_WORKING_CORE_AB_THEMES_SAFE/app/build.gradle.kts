plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}

val configuredApiBaseUrl = (
    project.findProperty("KHATMA_API_BASE_URL")
        ?: "https://balanced-creativity-production-f316.up.railway.app"
).toString()
val escapedApiBaseUrl = configuredApiBaseUrl.replace("\\", "\\\\").replace("\"", "\\\"")

android {
    namespace = "com.ab.khatma"
    compileSdk = 36

    defaultConfig {
        // Same production package as the known-working V0.4 APK.
        applicationId = "com.ab.khatma"
        minSdk = 26
        targetSdk = 36
        versionCode = 8
        versionName = "0.8.0"
    }

    buildTypes {
        debug {
            // Preview installs beside the working V0.4 instead of replacing it.
            applicationIdSuffix = ".preview"
            versionNameSuffix = "-preview"
            buildConfigField("String", "API_BASE_URL", "\"" + escapedApiBaseUrl + "\"")
        }
        release {
            buildConfigField("String", "API_BASE_URL", "\"" + escapedApiBaseUrl + "\"")
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    // Keep Android 36 compatible versions pinned in source; no CI-time sed patching.
    val composeBom = platform("androidx.compose:compose-bom:2026.06.00")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.activity:activity-compose:1.12.4")
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.10.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.10.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    implementation("androidx.work:work-runtime:2.11.2")
    implementation("com.batoulapps.adhan:adhan2:0.0.6")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
