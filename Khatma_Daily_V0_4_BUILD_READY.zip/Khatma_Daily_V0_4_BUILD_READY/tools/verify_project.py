from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
required = [
    ROOT / 'settings.gradle.kts',
    ROOT / 'build.gradle.kts',
    ROOT / 'gradle.properties',
    ROOT / 'app' / 'build.gradle.kts',
    ROOT / 'app' / 'src' / 'main' / 'AndroidManifest.xml',
    ROOT / 'app' / 'src' / 'main' / 'java' / 'com' / 'ab' / 'khatma' / 'MainActivity.kt',
    ROOT / 'server' / 'app' / 'main.py',
]
missing = [str(p.relative_to(ROOT)) for p in required if not p.exists()]
if missing:
    print('VERIFY FAIL - missing files:')
    for x in missing: print(' -', x)
    sys.exit(1)

app_gradle = (ROOT / 'app' / 'build.gradle.kts').read_text(encoding='utf-8')
checks = {
    'applicationId com.ab.khatma': 'applicationId = "com.ab.khatma"' in app_gradle,
    'versionCode 4': 'versionCode = 4' in app_gradle,
    'versionName 0.4.0': 'versionName = "0.4.0"' in app_gradle,
    'compileSdk 36': 'compileSdk = 36' in app_gradle,
    'targetSdk 36': 'targetSdk = 36' in app_gradle,
    'configurable API': 'KHATMA_API_BASE_URL' in app_gradle,
}
failed = [k for k,v in checks.items() if not v]
if failed:
    print('VERIFY FAIL - checks:')
    for x in failed: print(' -', x)
    sys.exit(1)

manifest=(ROOT/'app'/'src'/'main'/'AndroidManifest.xml').read_text(encoding='utf-8')
if 'android:usesCleartextTraffic="false"' not in manifest:
    print('VERIFY FAIL - cleartext traffic must remain disabled')
    sys.exit(1)

print('VERIFY PASS / AB Khatma V0.4.0 (4) / BUILD_READY')
