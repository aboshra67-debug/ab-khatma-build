AB Khatma V0.4.0 — BUILD_READY Android package
===============================================

Purpose
-------
This package follows the same CI build pattern used for AB Challenge:
- Android project module at app/
- verification script before build
- JDK 17
- Gradle 9.5.0
- Android SDK / Build Tools 36.0.0
- GitHub Actions produces an installable APK artifact

App identity
------------
applicationId: com.ab.khatma
versionCode: 4
versionName: 0.4.0
minSdk: 26
targetSdk / compileSdk: 36
Android Gradle Plugin: 9.3.0
Gradle: 9.5.0
JDK: 17

Server URL
----------
The Android app reads KHATMA_API_BASE_URL at build time.
For a real phone build, configure the GitHub repository variable:
KHATMA_API_BASE_URL = https://YOUR-REAL-SERVER.example

Do not use 10.0.2.2 for a real phone. That address is emulator-only.
Cleartext HTTP remains disabled in the main app manifest.

GitHub build
------------
Workflow: .github/workflows/khatma_build.yml
Output artifact: AB_Khatma_V0.4_TEST_APK
APK filename inside artifact: AB_Khatma_V0.4_TEST.apk

The workflow intentionally builds DEBUG for the current testing phase so the APK is automatically signed and directly installable. Before Google Play release, create a protected production signing configuration and build a release/AAB.

Verification
------------
python3 tools/verify_project.py
Expected:
VERIFY PASS / AB Khatma V0.4.0 (4) / BUILD_READY

Preserved functionality from V0.3
---------------------------------
- leader/member groups and daily juz assignment client logic
- offline completion queue and sync worker
- prayer reminder framework
- Quran reader framework / preferences
- FastAPI + PostgreSQL backend source under server/
- HTTPS-only main manifest

Important
---------
The current BUILD_READY package can compile without a live server URL, but group synchronization between real phones requires KHATMA_API_BASE_URL to point to a deployed HTTPS backend.
