package com.ab.khatma.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val KhatmaColors = lightColorScheme()

@Composable
fun KhatmaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = KhatmaColors,
        content = content,
    )
}
