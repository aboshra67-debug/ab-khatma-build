package com.ab.khatma.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.GroupAdd
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ab.khatma.model.TodayGroup

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    userName: String,
    groups: List<TodayGroup>,
    loading: Boolean,
    isOffline: Boolean,
    onRefresh: () -> Unit,
    onCreateGroup: () -> Unit,
    onJoinGroup: () -> Unit,
    onComplete: (TodayGroup) -> Unit,
    onLeaderOpen: (Long) -> Unit,
    onOpenQuran: (Int?) -> Unit,
    onOpenPrayerSettings: () -> Unit,
    onOpenAppearance: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("قراءاتي اليوم", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = onOpenAppearance) {
                        Icon(Icons.Rounded.Palette, contentDescription = "الثيمات")
                    }
                    IconButton(onClick = onOpenPrayerSettings) {
                        Icon(Icons.Rounded.Notifications, contentDescription = "التنبيهات")
                    }
                    IconButton(onClick = onRefresh) {
                        Icon(Icons.Rounded.Refresh, contentDescription = "تحديث")
                    }
                },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (isOffline) {
                item {
                    AssistChip(
                        onClick = onRefresh,
                        label = { Text("وضع بدون إنترنت — الإنجاز سيُزامن تلقائيًا") },
                    )
                }
            }

            item {
                Spacer(Modifier.height(4.dp))
                Text("السلام عليكم $userName", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(
                    if (groups.isEmpty()) "ابدأ بإنشاء مجموعة أو الانضمام لمجموعة"
                    else "لديك اليوم ${groups.count { it.membershipStatus == "active" }} مجموعات نشطة",
                    style = MaterialTheme.typography.bodyLarge,
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onCreateGroup, modifier = Modifier.weight(1f)) { Text("إنشاء مجموعة") }
                    OutlinedButton(onClick = onJoinGroup, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.GroupAdd, contentDescription = null)
                        Text(" انضمام")
                    }
                }
            }

            if (loading) item { LinearProgressIndicator(modifier = Modifier.fillMaxWidth()) }

            items(groups, key = { it.groupId }) { group ->
                GroupReadingCard(group, onComplete, onLeaderOpen, onOpenQuran)
            }

            item {
                Button(onClick = { onOpenQuran(null) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.MenuBook, contentDescription = null)
                    Text("  فتح المصحف")
                }
                OutlinedButton(onClick = onOpenPrayerSettings, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Notifications, contentDescription = null)
                    Text("  مواقيت الصلاة والتنبيهات")
                }
                Spacer(Modifier.height(20.dp))
            }
        }
    }
}

@Composable
private fun GroupReadingCard(
    group: TodayGroup,
    onComplete: (TodayGroup) -> Unit,
    onLeaderOpen: (Long) -> Unit,
    onOpenQuran: (Int?) -> Unit,
) {
    Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column {
                    Text(group.groupName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    if (group.membershipStatus == "pending") {
                        Text("بانتظار موافقة القائد", color = MaterialTheme.colorScheme.tertiary)
                    } else {
                        Text("جزؤك اليوم: ${group.juzNumber?.let { "الجزء $it" } ?: "لم يوزع بعد"}")
                        if ((group.khatmaNumber ?: 1) > 1) Text("الختمة رقم ${group.khatmaNumber}")
                    }
                }
                if (group.completed) Icon(Icons.Rounded.CheckCircle, contentDescription = "تم")
            }

            if (group.membershipStatus == "active") {
                Spacer(Modifier.height(12.dp))
                val progress = if (group.totalCount == 0) 0f else group.completedCount.toFloat() / group.totalCount
                Text("تقدم المجموعة: ${group.completedCount} من ${group.totalCount} أتموا اليوم")
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
                Spacer(Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onOpenQuran(group.juzNumber) },
                        modifier = Modifier.weight(1f),
                        enabled = group.juzNumber != null,
                    ) {
                        Text("ابدأ الجزء")
                    }
                    OutlinedButton(
                        onClick = { onComplete(group) },
                        modifier = Modifier.weight(1f),
                        enabled = !group.completed && group.assignmentId != null,
                    ) {
                        Text(if (group.completed) "تمت القراءة ✓" else "تمت القراءة")
                    }
                }

                Text(
                    "يمكنك الضغط على «تمت القراءة» حتى لو قرأت من مصحف ورقي.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 6.dp),
                )

                if (group.role == "leader" || group.role == "assistant") {
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { onLeaderOpen(group.groupId) }, modifier = Modifier.fillMaxWidth()) {
                        Text("فتح متابعة القائد")
                    }
                }
            }
        }
    }
}
