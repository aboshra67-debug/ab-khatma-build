package com.ab.khatma.ui.theme

import android.content.Context
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class KhatmaThemeStyle(val title: String, val subtitle: String) {
    NOOR("نور", "هادئ — عاجي وأخضر وذهبي"),
    EMERALD("زمرد", "أخضر مريح للقراءة اليومية"),
    NIGHT("ليلي", "داكن مريح للقراءة مساءً"),
}

class ThemePreferences(context: Context) {
    private val prefs = context.getSharedPreferences("khatma_appearance", Context.MODE_PRIVATE)

    fun load(): KhatmaThemeStyle = runCatching {
        KhatmaThemeStyle.valueOf(prefs.getString("theme_style", KhatmaThemeStyle.NOOR.name)!!)
    }.getOrDefault(KhatmaThemeStyle.NOOR)

    fun save(style: KhatmaThemeStyle) {
        prefs.edit().putString("theme_style", style.name).apply()
    }
}

private val NoorColors = lightColorScheme(
    primary = Color(0xFF0F6B4F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDDF4E9),
    onPrimaryContainer = Color(0xFF073A2A),
    secondary = Color(0xFFB78A2E),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE9AF),
    onSecondaryContainer = Color(0xFF4A3600),
    tertiary = Color(0xFF596B62),
    background = Color(0xFFFFFBF3),
    onBackground = Color(0xFF1D2823),
    surface = Color(0xFFFFFDF8),
    onSurface = Color(0xFF1D2823),
    surfaceVariant = Color(0xFFE8EFEA),
    outline = Color(0xFF76837C),
)

private val EmeraldColors = lightColorScheme(
    primary = Color(0xFF006B5B),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF8CF8DC),
    onPrimaryContainer = Color(0xFF00201A),
    secondary = Color(0xFF8B6F2D),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE49A),
    onSecondaryContainer = Color(0xFF2C2200),
    tertiary = Color(0xFF3D6373),
    background = Color(0xFFF3FAF7),
    onBackground = Color(0xFF172521),
    surface = Color(0xFFFAFFFC),
    onSurface = Color(0xFF172521),
    surfaceVariant = Color(0xFFDCEBE5),
    outline = Color(0xFF6C7B76),
)

private val NightColors = darkColorScheme(
    primary = Color(0xFFD9B85D),
    onPrimary = Color(0xFF3B2F00),
    primaryContainer = Color(0xFF554500),
    onPrimaryContainer = Color(0xFFFFE58E),
    secondary = Color(0xFF80D7B7),
    onSecondary = Color(0xFF00382B),
    secondaryContainer = Color(0xFF00513F),
    onSecondaryContainer = Color(0xFF9CF4D1),
    tertiary = Color(0xFF9BCBDA),
    background = Color(0xFF0D1714),
    onBackground = Color(0xFFDCE6E1),
    surface = Color(0xFF14211D),
    onSurface = Color(0xFFDCE6E1),
    surfaceVariant = Color(0xFF2A3833),
    outline = Color(0xFF899790),
)

@Composable
fun KhatmaTheme(style: KhatmaThemeStyle, content: @Composable () -> Unit) {
    val colors = when (style) {
        KhatmaThemeStyle.NOOR -> NoorColors
        KhatmaThemeStyle.EMERALD -> EmeraldColors
        KhatmaThemeStyle.NIGHT -> NightColors
    }
    MaterialTheme(
        colorScheme = colors,
        content = content,
    )
}
