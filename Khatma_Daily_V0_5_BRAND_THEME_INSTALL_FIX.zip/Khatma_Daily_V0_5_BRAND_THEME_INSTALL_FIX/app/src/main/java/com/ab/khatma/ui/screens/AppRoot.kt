package com.ab.khatma.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.ab.khatma.AppViewModel
import com.ab.khatma.ui.theme.KhatmaThemeStyle
import kotlinx.coroutines.delay

private sealed interface Screen {
    data object Welcome : Screen
    data object Home : Screen
    data object CreateGroup : Screen
    data object JoinGroup : Screen
    data object PrayerSettings : Screen
    data object Appearance : Screen
    data class Quran(val juz: Int?) : Screen
    data class Leader(val groupId: Long) : Screen
}

@Composable
fun AppRoot(vm: AppViewModel, themeStyle: KhatmaThemeStyle, onThemeStyleChange: (KhatmaThemeStyle) -> Unit) {
    var screen by remember { mutableStateOf<Screen>(if (vm.userId > 0) Screen.Home else Screen.Welcome) }

    vm.error?.let { message ->
        AlertDialog(
            onDismissRequest = vm::clearError,
            confirmButton = { TextButton(onClick = vm::clearError) { Text("حسنًا") } },
            title = { Text("تنبيه") },
            text = { Text(message) },
        )
    }

    vm.lastCreatedGroup?.let { group ->
        AlertDialog(
            onDismissRequest = vm::clearCreatedGroup,
            confirmButton = { TextButton(onClick = vm::clearCreatedGroup) { Text("تم") } },
            title = { Text("تم إنشاء المجموعة") },
            text = { Text("كود الدعوة: ${group.inviteCode}\nأرسله للأعضاء للانضمام للمجموعة.") },
        )
    }

    when (val current = screen) {
        Screen.Welcome -> WelcomeScreen(vm.loading) { name -> vm.register(name) { screen = Screen.Home } }
        Screen.Home -> HomeScreen(
            userName = vm.userName,
            groups = vm.groups,
            loading = vm.loading,
            isOffline = vm.isOffline,
            onRefresh = vm::refreshToday,
            onCreateGroup = { screen = Screen.CreateGroup },
            onJoinGroup = { screen = Screen.JoinGroup },
            onComplete = vm::complete,
            onLeaderOpen = { id -> vm.loadLeaderStatus(id); screen = Screen.Leader(id) },
            onOpenQuran = { juz -> screen = Screen.Quran(juz) },
            onOpenPrayerSettings = { screen = Screen.PrayerSettings },
            onOpenAppearance = { screen = Screen.Appearance },
        )
        Screen.CreateGroup -> CreateGroupScreen(vm.loading, onBack = { screen = Screen.Home }) { name, participates ->
            vm.createGroup(name, participates) { screen = Screen.Home }
        }
        Screen.JoinGroup -> JoinGroupScreen(vm.loading, onBack = { screen = Screen.Home }) { code ->
            vm.joinGroup(code) { screen = Screen.Home }
        }
        Screen.PrayerSettings -> PrayerSettingsScreen(onBack = { screen = Screen.Home })
        Screen.Appearance -> AppearanceScreen(themeStyle, onThemeStyleChange, onBack = { screen = Screen.Home })
        is Screen.Quran -> QuranScreen(initialJuz = current.juz, onBack = { screen = Screen.Home })
        is Screen.Leader -> {
            LaunchedEffect(current.groupId) {
                while (true) {
                    delay(5_000)
                    vm.loadLeaderStatus(current.groupId)
                }
            }
            LeaderGroupScreen(
                status = vm.leaderStatus,
                pending = vm.pendingMembers,
                loading = vm.loading,
                onBack = { screen = Screen.Home },
                onRefresh = { vm.loadLeaderStatus(current.groupId) },
                onApprove = { membershipId, approve -> vm.approveMember(current.groupId, membershipId, approve) },
                onChangeJuz = { membershipId, juz -> vm.changeMemberJuz(current.groupId, membershipId, juz) },
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WelcomeScreen(loading: Boolean, onRegister: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    Scaffold(topBar = { TopAppBar(title = { Text("ختمة", fontWeight = FontWeight.Bold) }) }) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            verticalArrangement = Arrangement.Center,
        ) {
            Text("أهلًا بك", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("اكتب اسمك للبدء. التحقق برقم الهاتف سيضاف في مرحلة الأمان.")
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("الاسم") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            Button(onClick = { onRegister(name) }, enabled = name.trim().length >= 2 && !loading, modifier = Modifier.fillMaxWidth()) {
                Text(if (loading) "جاري التسجيل..." else "ابدأ")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CreateGroupScreen(loading: Boolean, onBack: () -> Unit, onCreate: (String, Boolean) -> Unit) {
    var name by remember { mutableStateOf("") }
    var participates by remember { mutableStateOf(false) }
    Scaffold(topBar = { TopAppBar(title = { Text("إنشاء مجموعة") }, navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } }) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("اسم المجموعة") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            Text("الانضمام يحتاج موافقة القائد افتراضيًا.")
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("القائد يشارك كقارئ ويأخذ جزءًا")
                Switch(checked = participates, onCheckedChange = { participates = it })
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = { onCreate(name, participates) }, enabled = name.trim().length >= 2 && !loading, modifier = Modifier.fillMaxWidth()) {
                Text("إنشاء المجموعة")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun JoinGroupScreen(loading: Boolean, onBack: () -> Unit, onJoin: (String) -> Unit) {
    var code by remember { mutableStateOf("") }
    Scaffold(topBar = { TopAppBar(title = { Text("الانضمام لمجموعة") }, navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } }) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            OutlinedTextField(
                value = code,
                onValueChange = { code = it.uppercase() },
                label = { Text("كود المجموعة") },
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = { onJoin(code) }, enabled = code.trim().length >= 4 && !loading, modifier = Modifier.fillMaxWidth()) {
                Text("إرسال طلب الانضمام")
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppearanceScreen(
    selected: KhatmaThemeStyle,
    onSelect: (KhatmaThemeStyle) -> Unit,
    onBack: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("المظهر والثيمات", fontWeight = FontWeight.Bold) },
                navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("اختر الثيم المناسب لك. الاختيار يُحفظ تلقائيًا على الجهاز.")
            KhatmaThemeStyle.entries.forEach { style ->
                Card(
                    onClick = { onSelect(style) },
                    modifier = Modifier.fillMaxWidth(),
                    elevation = CardDefaults.cardElevation(defaultElevation = if (selected == style) 4.dp else 1.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(style.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text(style.subtitle, style = MaterialTheme.typography.bodyMedium)
                        }
                        RadioButton(selected = selected == style, onClick = { onSelect(style) })
                    }
                }
            }
        }
    }
}
