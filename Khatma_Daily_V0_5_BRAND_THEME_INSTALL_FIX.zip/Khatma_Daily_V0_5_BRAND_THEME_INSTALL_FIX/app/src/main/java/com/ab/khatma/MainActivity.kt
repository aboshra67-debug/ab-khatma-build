package com.ab.khatma

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ab.khatma.ui.screens.AppRoot
import com.ab.khatma.ui.theme.KhatmaTheme
import com.ab.khatma.ui.theme.ThemePreferences

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            val context = LocalContext.current
            val themePrefs = remember { ThemePreferences(context) }
            var themeStyle by remember { mutableStateOf(themePrefs.load()) }

            KhatmaTheme(themeStyle) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    androidx.compose.material3.Surface(modifier = Modifier.fillMaxSize()) {
                        val vm: AppViewModel = viewModel()
                        AppRoot(
                            vm = vm,
                            themeStyle = themeStyle,
                            onThemeStyleChange = { style ->
                                themePrefs.save(style)
                                themeStyle = style
                            },
                        )
                    }
                }
            }
        }
    }
}
